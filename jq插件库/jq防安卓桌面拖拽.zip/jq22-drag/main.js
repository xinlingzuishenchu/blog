(function(){
	registerDrag($('#container'));
})();