var isTop, testDiv, scrollIntervalId,
    isBrowser = typeof window !== "undefined" && window.document,
    isPageLoaded = !isBrowser,
    doc = isBrowser ? document : null,
    readyCalls = [];

function runCallbacks(callbacks) {
    var i;
    for (i = 0; i < callbacks.length; i += 1) {
        callbacks[i](doc);
    }
}

function callReady() {
    var callbacks = readyCalls;

    if (isPageLoaded) {
        //Call the DOM ready callbacks
        if (callbacks.length) {
            readyCalls = [];
            runCallbacks(callbacks);
        }
    }
}

/**
 * Sets the page as loaded.
 */
function pageLoaded() {
    if (!isPageLoaded) {
        isPageLoaded = true;
        if (scrollIntervalId) {
            clearInterval(scrollIntervalId);
        }

        callReady();
    }
}

if (isBrowser) {
    if (document.addEventListener) {
        //Standards. Hooray! Assumption here that if standards based,
        //it knows about DOMContentLoaded.
        document.addEventListener("DOMContentLoaded", pageLoaded, false);
        window.addEventListener("load", pageLoaded, false);
    } else if (window.attachEvent) {
        window.attachEvent("onload", pageLoaded);

        testDiv = document.createElement('div');
        try {
            isTop = window.frameElement === null;
        } catch (e) {}

        //DOMContentLoaded approximation that uses a doScroll, as found by
        //Diego Perini: http://javascript.nwbox.com/IEContentLoaded/,
        //but modified by other contributors, including jdalton
        if (testDiv.doScroll && isTop && window.external) {
            scrollIntervalId = setInterval(function() {
                try {
                    testDiv.doScroll();
                    pageLoaded();
                } catch (e) {}
            }, 30);
        }
    }

    //Check if document already complete, and if so, just trigger page load
    //listeners. Latest webkit browsers also use "interactive", and
    //will fire the onDOMContentLoaded before "interactive" but not after
    //entering "interactive" or "complete". More details:
    //http://dev.w3.org/html5/spec/the-end.html#the-end
    //http://stackoverflow.com/questions/3665561/document-readystate-of-interactive-vs-ondomcontentloaded
    //Hmm, this is more complicated on further use, see "firing too early"
    //bug: https://github.com/requirejs/domReady/issues/1
    //so removing the || document.readyState === "interactive" test.
    //There is still a window.onload binding that should get fired if
    //DOMContentLoaded is missed.
    if (document.readyState === "complete") {
        pageLoaded();
    }
}

/** START OF PUBLIC API **/

/**
 * Registers a callback for DOM ready. If DOM is already ready, the
 * callback is called immediately.
 * @param {Function} callback
 */
function domReady(callback) {
    if (isPageLoaded) {
        callback(doc);
    } else {
        readyCalls.push(callback);
    }
    return domReady;
}

domReady.version = '2.0.1';

/**
 * Loader Plugin API method
 */
domReady.load = function(name, req, onLoad, config) {
    if (config.isBuild) {
        onLoad(null);
    } else {
        domReady(onLoad);
    }
};


domReady(function() {
    var desktop = jtop.init('jtop', {
        scrollView: {
            initY: 25
        }
    });

    var cMenuProject = jtop.popupmenu()
        .addMenuElement('open project', null, function(sender) {
            alert('open project ' + sender.title);
        }, 'edit-item')
        .addMenuSeparator()
        .addMenuElement('preview project', null, function(sender) {
            alert('open project ' + sender.title);
        }, 'preview-project')
        .addMenuElement('remove', null, function(sender) {
            if (sender.parent.type === 'PANEL' && _.keys(sender.parent.items).length == 1) {
                sender.parent.remove();
            }
            sender.remove();
        }, 'remove');

    var iconTooltip = desktop.tooltip({
            offsetLeft: 30,
            offsetTop: -120,
        })
        .addTemplate('<%if(image) {%><img class="image" src="<%=image%>"/><%}%>' +
            '<div class="title"><%=title%></div>' +
            '<div class="description"><%=description%></div>' +
            '<div class="field"><%=field%></div>')
        .addTemplate(' ');

    iconTooltip.on.show.add(function(sender, values) {
        values.title = sender.settings.title;
        values.image = 'http://ns3002439.ovh.net/thumbs/rozne/thumb-2274542.jpg';
        values.description = sender.settings.title;
        values.field = 'Jtop project';
    });

    var icons = [];

    icons[0] = desktop.icon({ title: 'Some very long text applied to this icon can be seen here it is good i hope', image: 'imgs/db.png', gridX: 1, gridY: 1 })
        .menu(cMenuProject).
    tooltip(iconTooltip);;

    icons[1] = desktop.icon({ title: 'Secon element. Shorten text applied.', image: 'imgs/box.png', gridX: 2, gridY: 1 })
        .menu(cMenuProject)
        .tooltip(iconTooltip);

    icons[2] = desktop.icon({ title: 'Short named element', image: 'imgs/bird.png', gridX: 3, gridY: 1 })
        .menu(cMenuProject)
        .tooltip(iconTooltip);

    icons[3] = desktop.icon({ title: 'Different element', image: 'imgs/box.png', gridX: 2, gridY: 2 })
        .menu(cMenuProject)
        .tooltip(iconTooltip);

    icons[4] = desktop.icon({ title: 'Test project, some very long text.', image: 'imgs/db.png', gridX: 1, gridY: 2 })
        .menu(cMenuProject)
        .tooltip(iconTooltip);

    icons[5] = desktop.icon({ title: 'Secon element. Shorten text applied.', image: 'imgs/box.png', gridX: 3, gridY: 3 })
        .menu(cMenuProject)
        .tooltip(iconTooltip);

    icons[6] = desktop.icon({ title: 'Short named element', image: 'imgs/bird.png', gridX: 3, gridY: 2 })
        .menu(cMenuProject)
        .tooltip(iconTooltip);

    icons[7] = desktop.icon({ title: 'Different element', image: 'imgs/box.png', gridX: 2, gridY: 3 })
        .menu(cMenuProject)
        .tooltip(iconTooltip);



    var p = desktop.panel({ title: 'Some very long text with this custom panel item' }).pos(500, 100);
    var r = desktop.panel({ title: 'Different panel', width: 200, height: 160 }).pos(800, 100);

    p.addItem(icons[7], 0, 0, true);

    // automated create panels functionality
    var panelTooltip = desktop.tooltip({
            className: 'jt-tooltip-info',
            offsetLeft: 0,
            offsetTop: 0,
            toOpacity: 1
        })
        .addTemplate('<div class="image"></div><div class="title"><span class="name"><%=name%></span> <%=title%></div>');

    panelTooltip.on.show.add(function(sender, values) {
        values.name = '<span class="name">+ Create panel</span>';
        values.title = sender.settings.title;
    });

    desktop.on.dragOverItem.add(function(item, itemBelow, x, y) {
        panelTooltip.show(itemBelow, x, y);
    });

    desktop.on.dragOutItem.add(function(item) {
        panelTooltip.hide();
    });

    desktop.on.dropInItem.add(function(item, itemBelow) {
        panelTooltip.hide();
        var newPanel = desktop.panel({ title: itemBelow.settings.title, width: 200, height: 80 }).pos(itemBelow.transform.x, itemBelow.transform.y + 25);

        desktop.grid.removeValue(itemBelow.settings.gridX, itemBelow.settings.gridY, itemBelow);
        desktop.grid.removeValue(item.settings.gridX, item.settings.gridY, item);

        newPanel.addItem(item, 1, 0, true);
        newPanel.addItem(itemBelow, 0, 0, true);

        return true;
    });

    // automated remove panels functionality
    var panelToRemove = null;
    desktop.on.dragStart.add(function(item, x, y) {
        if (item.parent.type === 'PANEL' && _.keys(item.parent.items).length == 0) {
            panelToRemove = item.parent;
        } else {
            panelToRemove = null;
        }
    });

    desktop.on.dragEnd.add(function(item, x, y) {
        if (item.parent !== panelToRemove) {
            panelToRemove && panelToRemove.remove();
        }
    });

});