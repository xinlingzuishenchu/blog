/**
 * almond 0.2.0 Copyright (c) 2011, The Dojo Foundation All Rights Reserved.
 * Available via the MIT or new BSD license.
 * see: http://github.com/jrburke/almond for details
 */

//     (c) 2009-2012 Jeremy Ashkenas, DocumentCloud Inc.

//     Underscore is freely distributable under the MIT license.

/** @license
 * JS Signals <http://millermedeiros.github.com/js-signals/>
 * Released under the MIT license
 * Author: Miller Medeiros
 * Version: 0.8.1 - Build: 266 (2012/07/31 03:33 PM)
 */

(function() {
    var e, t, n;
    (function(r) {
        function p(e, t) {
            var n, r, i, s, o, u, a, f, c, h, p = t && t.split("/"),
                d = l.map,
                v = d && d["*"] || {};
            if (e && e.charAt(0) === "." && t) {
                p = p.slice(0, p.length - 1), e = p.concat(e.split("/"));
                for (f = 0; f < e.length; f += 1) {
                    h = e[f];
                    if (h === ".") e.splice(f, 1), f -= 1;
                    else if (h === "..") {
                        if (f === 1 && (e[2] === ".." || e[0] === "..")) break;
                        f > 0 && (e.splice(f - 1, 2), f -= 2)
                    }
                }
                e = e.join("/")
            }
            if ((p || v) && d) {
                n = e.split("/");
                for (f = n.length; f > 0; f -= 1) {
                    r = n.slice(0, f).join("/");
                    if (p)
                        for (c = p.length; c > 0; c -= 1) {
                            i = d[p.slice(0, c).join("/")];
                            if (i) {
                                i = i[r];
                                if (i) {
                                    s = i, o = f;
                                    break
                                }
                            }
                        }
                    if (s) break;
                    !u && v && v[r] && (u = v[r], a = f)
                }!s && u && (s = u, o = a), s && (n.splice(0, o, s), e = n.join("/"))
            }
            return e
        }

        function d(e, t) {
            return function() {
                return s.apply(r, h.call(arguments, 0).concat([e, t]))
            }
        }

        function v(e) {
            return function(t) {
                return p(t, e)
            }
        }

        function m(e) {
            return function(t) {
                a[e] = t
            }
        }

        function g(e) {
            if (f.hasOwnProperty(e)) {
                var t = f[e];
                delete f[e], c[e] = !0, i.apply(r, t)
            }
            if (!a.hasOwnProperty(e) && !c.hasOwnProperty(e)) throw new Error("No " + e);
            return a[e]
        }

        function y(e) {
            var t, n = e ? e.indexOf("!") : -1;
            return n > -1 && (t = e.substring(0, n), e = e.substring(n + 1, e.length)), [t, e]
        }

        function b(e) {
            return function() {
                return l && l.config && l.config[e] || {}
            }
        }
        var i, s, o, u, a = {},
            f = {},
            l = {},
            c = {},
            h = [].slice;
        o = function(e, t) {
            var n, r = y(e),
                i = r[0];
            return e = r[1], i && (i = p(i, t), n = g(i)), i ? n && n.normalize ? e = n.normalize(e, v(t)) : e = p(e, t) : (e = p(e, t), r = y(e), i = r[0], e = r[1], i && (n = g(i))), {
                f: i ? i + "!" + e : e,
                n: e,
                pr: i,
                p: n
            }
        }, u = {
            require: function(e) {
                return d(e)
            },
            exports: function(e) {
                var t = a[e];
                return typeof t != "undefined" ? t : a[e] = {}
            },
            module: function(e) {
                return {
                    id: e,
                    uri: "",
                    exports: a[e],
                    config: b(e)
                }
            }
        }, i = function(e, t, n, i) {
            var s, l, h, p, v, y = [],
                b;
            i = i || e;
            if (typeof n == "function") {
                t = !t.length && n.length ? ["require", "exports", "module"] : t;
                for (v = 0; v < t.length; v += 1) {
                    p = o(t[v], i), l = p.f;
                    if (l === "require") y[v] = u.require(e);
                    else if (l === "exports") y[v] = u.exports(e), b = !0;
                    else if (l === "module") s = y[v] = u.module(e);
                    else if (a.hasOwnProperty(l) || f.hasOwnProperty(l) || c.hasOwnProperty(l)) y[v] = g(l);
                    else {
                        if (!p.p) throw new Error(e + " missing " + l);
                        p.p.load(p.n, d(i, !0), m(l), {}), y[v] = a[l]
                    }
                }
                h = n.apply(a[e], y);
                if (e)
                    if (s && s.exports !== r && s.exports !== a[e]) a[e] = s.exports;
                    else if (h !== r || !b) a[e] = h
            } else e && (a[e] = n)
        }, e = t = s = function(e, t, n, a, f) {
            return typeof e == "string" ? u[e] ? u[e](t) : g(o(e, t).f) : (e.splice || (l = e, t.splice ? (e = t, t = n, n = null) : e = r), t = t ||
                function() {}, typeof n == "function" && (n = a, a = f), a ? i(r, e, t, n) : setTimeout(function() {
                    i(r, e, t, n)
                }, 15), s)
        }, s.config = function(e) {
            return l = e, s
        }, n = function(e, t, n) {
            t.splice || (n = t, t = []), f[e] = [e, t, n]
        }, n.amd = {
            jQuery: !0
        }
    })(), n("../build/almond.js", function() {}),
        function() {
            function C(e, t, n) {
                if (e === t) return e !== 0 || 1 / e == 1 / t;
                if (e == null || t == null) return e === t;
                e._chain && (e = e._wrapped), t._chain && (t = t._wrapped);
                if (e.isEqual && S.isFunction(e.isEqual)) return e.isEqual(t);
                if (t.isEqual && S.isFunction(t.isEqual)) return t.isEqual(e);
                var r = a.call(e);
                if (r != a.call(t)) return !1;
                switch (r) {
                    case "[object String]":
                        return e == String(t);
                    case "[object Number]":
                        return e != +e ? t != +t : e == 0 ? 1 / e == 1 / t : e == +t;
                    case "[object Date]":
                    case "[object Boolean]":
                        return +e == +t;
                    case "[object RegExp]":
                        return e.source == t.source && e.global == t.global && e.multiline == t.multiline && e.ignoreCase == t.ignoreCase
                }
                if (typeof e != "object" || typeof t != "object") return !1;
                var i = n.length;
                while (i--)
                    if (n[i] == e) return !0;
                n.push(e);
                var s = 0,
                    o = !0;
                if (r == "[object Array]") {
                    s = e.length, o = s == t.length;
                    if (o)
                        while (s--)
                            if (!(o = s in e == s in t && C(e[s], t[s], n))) break
                } else {
                    if ("constructor" in e != "constructor" in t || e.constructor != t.constructor) return !1;
                    for (var u in e)
                        if (S.has(e, u)) {
                            s++;
                            if (!(o = S.has(t, u) && C(e[u], t[u], n))) break
                        }
                    if (o) {
                        for (u in t)
                            if (S.has(t, u) && !(s--)) break;
                        o = !s
                    }
                }
                return n.pop(), o
            }
            var e = this,
                t = e._,
                n = {},
                r = Array.prototype,
                i = Object.prototype,
                s = Function.prototype,
                o = r.slice,
                u = r.unshift,
                a = i.toString,
                f = i.hasOwnProperty,
                l = r.forEach,
                c = r.map,
                h = r.reduce,
                p = r.reduceRight,
                d = r.filter,
                v = r.every,
                m = r.some,
                g = r.indexOf,
                y = r.lastIndexOf,
                b = Array.isArray,
                w = Object.keys,
                E = s.bind,
                S = function(e) {
                    return new P(e)
                };
            typeof exports != "undefined" ? (typeof module != "undefined" && module.exports && (exports = module.exports = S), exports._ = S) : e._ = S, S.VERSION = "1.3.3";
            var x = S.each = S.forEach = function(e, t, r) {
                if (e == null) return;
                if (l && e.forEach === l) e.forEach(t, r);
                else if (e.length === +e.length) {
                    for (var i = 0, s = e.length; i < s; i++)
                        if (i in e && t.call(r, e[i], i, e) === n) return
                } else
                    for (var o in e)
                        if (S.has(e, o) && t.call(r, e[o], o, e) === n) return
            };
            S.map = S.collect = function(e, t, n) {
                var r = [];
                return e == null ? r : c && e.map === c ? e.map(t, n) : (x(e, function(e, i, s) {
                    r[r.length] = t.call(n, e, i, s)
                }), e.length === +e.length && (r.length = e.length), r)
            }, S.reduce = S.foldl = S.inject = function(e, t, n, r) {
                var i = arguments.length > 2;
                e == null && (e = []);
                if (h && e.reduce === h) return r && (t = S.bind(t, r)), i ? e.reduce(t, n) : e.reduce(t);
                x(e, function(e, s, o) {
                    i ? n = t.call(r, n, e, s, o) : (n = e, i = !0)
                });
                if (!i) throw new TypeError("Reduce of empty array with no initial value");
                return n
            }, S.reduceRight = S.foldr = function(e, t, n, r) {
                var i = arguments.length > 2;
                e == null && (e = []);
                if (p && e.reduceRight === p) return r && (t = S.bind(t, r)), i ? e.reduceRight(t, n) : e.reduceRight(t);
                var s = S.toArray(e).reverse();
                return r && !i && (t = S.bind(t, r)), i ? S.reduce(s, t, n, r) : S.reduce(s, t)
            }, S.find = S.detect = function(e, t, n) {
                var r;
                return T(e, function(e, i, s) {
                    if (t.call(n, e, i, s)) return r = e, !0
                }), r
            }, S.filter = S.select = function(e, t, n) {
                var r = [];
                return e == null ? r : d && e.filter === d ? e.filter(t, n) : (x(e, function(e, i, s) {
                    t.call(n, e, i, s) && (r[r.length] = e)
                }), r)
            }, S.reject = function(e, t, n) {
                var r = [];
                return e == null ? r : (x(e, function(e, i, s) {
                    t.call(n, e, i, s) || (r[r.length] = e)
                }), r)
            }, S.every = S.all = function(e, t, r) {
                var i = !0;
                return e == null ? i : v && e.every === v ? e.every(t, r) : (x(e, function(e, s, o) {
                    if (!(i = i && t.call(r, e, s, o))) return n
                }), !!i)
            };
            var T = S.some = S.any = function(e, t, r) {
                t || (t = S.identity);
                var i = !1;
                return e == null ? i : m && e.some === m ? e.some(t, r) : (x(e, function(e, s, o) {
                    if (i || (i = t.call(r, e, s, o))) return n
                }), !!i)
            };
            S.include = S.contains = function(e, t) {
                var n = !1;
                return e == null ? n : g && e.indexOf === g ? e.indexOf(t) != -1 : (n = T(e, function(e) {
                    return e === t
                }), n)
            }, S.invoke = function(e, t) {
                var n = o.call(arguments, 2);
                return S.map(e, function(e) {
                    return (S.isFunction(t) ? t || e : e[t]).apply(e, n)
                })
            }, S.pluck = function(e, t) {
                return S.map(e, function(e) {
                    return e[t]
                })
            }, S.max = function(e, t, n) {
                if (!t && S.isArray(e) && e[0] === +e[0]) return Math.max.apply(Math, e);
                if (!t && S.isEmpty(e)) return -Infinity;
                var r = {
                    computed: -Infinity
                };
                return x(e, function(e, i, s) {
                    var o = t ? t.call(n, e, i, s) : e;
                    o >= r.computed && (r = {
                        value: e,
                        computed: o
                    })
                }), r.value
            }, S.min = function(e, t, n) {
                if (!t && S.isArray(e) && e[0] === +e[0]) return Math.min.apply(Math, e);
                if (!t && S.isEmpty(e)) return Infinity;
                var r = {
                    computed: Infinity
                };
                return x(e, function(e, i, s) {
                    var o = t ? t.call(n, e, i, s) : e;
                    o < r.computed && (r = {
                        value: e,
                        computed: o
                    })
                }), r.value
            }, S.shuffle = function(e) {
                var t = [],
                    n;
                return x(e, function(e, r, i) {
                    n = Math.floor(Math.random() * (r + 1)), t[r] = t[n], t[n] = e
                }), t
            }, S.sortBy = function(e, t, n) {
                var r = S.isFunction(t) ? t : function(e) {
                    return e[t]
                };
                return S.pluck(S.map(e, function(e, t, i) {
                    return {
                        value: e,
                        criteria: r.call(n, e, t, i)
                    }
                }).sort(function(e, t) {
                    var n = e.criteria,
                        r = t.criteria;
                    return n === void 0 ? 1 : r === void 0 ? -1 : n < r ? -1 : n > r ? 1 : 0
                }), "value")
            }, S.groupBy = function(e, t) {
                var n = {},
                    r = S.isFunction(t) ? t : function(e) {
                        return e[t]
                    };
                return x(e, function(e, t) {
                    var i = r(e, t);
                    (n[i] || (n[i] = [])).push(e)
                }), n
            }, S.sortedIndex = function(e, t, n) {
                n || (n = S.identity);
                var r = 0,
                    i = e.length;
                while (r < i) {
                    var s = r + i >> 1;
                    n(e[s]) < n(t) ? r = s + 1 : i = s
                }
                return r
            }, S.toArray = function(e) {
                return e ? S.isArray(e) ? o.call(e) : S.isArguments(e) ? o.call(e) : e.toArray && S.isFunction(e.toArray) ? e.toArray() : S.values(e) : []
            }, S.size = function(e) {
                return S.isArray(e) ? e.length : S.keys(e).length
            }, S.first = S.head = S.take = function(e, t, n) {
                return t != null && !n ? o.call(e, 0, t) : e[0]
            }, S.initial = function(e, t, n) {
                return o.call(e, 0, e.length - (t == null || n ? 1 : t))
            }, S.last = function(e, t, n) {
                return t != null && !n ? o.call(e, Math.max(e.length - t, 0)) : e[e.length - 1]
            }, S.rest = S.tail = function(e, t, n) {
                return o.call(e, t == null || n ? 1 : t)
            }, S.compact = function(e) {
                return S.filter(e, function(e) {
                    return !!e
                })
            }, S.flatten = function(e, t) {
                return S.reduce(e, function(e, n) {
                    return S.isArray(n) ? e.concat(t ? n : S.flatten(n)) : (e[e.length] = n, e)
                }, [])
            }, S.without = function(e) {
                return S.difference(e, o.call(arguments, 1))
            }, S.uniq = S.unique = function(e, t, n) {
                var r = n ? S.map(e, n) : e,
                    i = [];
                return e.length < 3 && (t = !0), S.reduce(r, function(n, r, s) {
                    if (t ? S.last(n) !== r || !n.length : !S.include(n, r)) n.push(r), i.push(e[s]);
                    return n
                }, []), i
            }, S.union = function() {
                return S.uniq(S.flatten(arguments, !0))
            }, S.intersection = S.intersect = function(e) {
                var t = o.call(arguments, 1);
                return S.filter(S.uniq(e), function(e) {
                    return S.every(t, function(t) {
                        return S.indexOf(t, e) >= 0
                    })
                })
            }, S.difference = function(e) {
                var t = S.flatten(o.call(arguments, 1), !0);
                return S.filter(e, function(e) {
                    return !S.include(t, e)
                })
            }, S.zip = function() {
                var e = o.call(arguments),
                    t = S.max(S.pluck(e, "length")),
                    n = new Array(t);
                for (var r = 0; r < t; r++) n[r] = S.pluck(e, "" + r);
                return n
            }, S.indexOf = function(e, t, n) {
                if (e == null) return -1;
                var r, i;
                if (n) return r = S.sortedIndex(e, t), e[r] === t ? r : -1;
                if (g && e.indexOf === g) return e.indexOf(t);
                for (r = 0, i = e.length; r < i; r++)
                    if (r in e && e[r] === t) return r;
                return -1
            }, S.lastIndexOf = function(e, t) {
                if (e == null) return -1;
                if (y && e.lastIndexOf === y) return e.lastIndexOf(t);
                var n = e.length;
                while (n--)
                    if (n in e && e[n] === t) return n;
                return -1
            }, S.range = function(e, t, n) {
                arguments.length <= 1 && (t = e || 0, e = 0), n = arguments[2] || 1;
                var r = Math.max(Math.ceil((t - e) / n), 0),
                    i = 0,
                    s = new Array(r);
                while (i < r) s[i++] = e, e += n;
                return s
            };
            var N = function() {};
            S.bind = function(t, n) {
                    var r, i;
                    if (t.bind === E && E) return E.apply(t, o.call(arguments, 1));
                    if (!S.isFunction(t)) throw new TypeError;
                    return i = o.call(arguments, 2), r = function() {
                        if (this instanceof r) {
                            N.prototype = t.prototype;
                            var e = new N,
                                s = t.apply(e, i.concat(o.call(arguments)));
                            return Object(s) === s ? s : e
                        }
                        return t.apply(n, i.concat(o.call(arguments)))
                    }
                }, S.bindAll = function(e) {
                    var t = o.call(arguments, 1);
                    return t.length == 0 && (t = S.functions(e)), x(t, function(t) {
                        e[t] = S.bind(e[t], e)
                    }), e
                }, S.memoize = function(e, t) {
                    var n = {};
                    return t || (t = S.identity),
                        function() {
                            var r = t.apply(this, arguments);
                            return S.has(n, r) ? n[r] : n[r] = e.apply(this, arguments)
                        }
                }, S.delay = function(e, t) {
                    var n = o.call(arguments, 2);
                    return setTimeout(function() {
                        return e.apply(null, n)
                    }, t)
                }, S.defer = function(e) {
                    return S.delay.apply(S, [e, 1].concat(o.call(arguments, 1)))
                }, S.throttle = function(e, t) {
                    var n, r, i, s, o, u, a = S.debounce(function() {
                        o = s = !1
                    }, t);
                    return function() {
                        n = this, r = arguments;
                        var f = function() {
                            i = null, o && e.apply(n, r), a()
                        };
                        return i || (i = setTimeout(f, t)), s ? o = !0 : u = e.apply(n, r), a(), s = !0, u
                    }
                }, S.debounce = function(e, t, n) {
                    var r;
                    return function() {
                        var i = this,
                            s = arguments,
                            o = function() {
                                r = null, n || e.apply(i, s)
                            };
                        n && !r && e.apply(i, s), clearTimeout(r), r = setTimeout(o, t)
                    }
                }, S.once = function(e) {
                    var t = !1,
                        n;
                    return function() {
                        return t ? n : (t = !0, n = e.apply(this, arguments))
                    }
                }, S.wrap = function(e, t) {
                    return function() {
                        var n = [e].concat(o.call(arguments, 0));
                        return t.apply(this, n)
                    }
                }, S.compose = function() {
                    var e = arguments;
                    return function() {
                        var t = arguments;
                        for (var n = e.length - 1; n >= 0; n--) t = [e[n].apply(this, t)];
                        return t[0]
                    }
                }, S.after = function(e, t) {
                    return e <= 0 ? t() : function() {
                        if (--e < 1) return t.apply(this, arguments)
                    }
                }, S.keys = w ||
                function(e) {
                    if (e !== Object(e)) throw new TypeError("Invalid object");
                    var t = [];
                    for (var n in e) S.has(e, n) && (t[t.length] = n);
                    return t
                }, S.values = function(e) {
                    return S.map(e, S.identity)
                }, S.functions = S.methods = function(e) {
                    var t = [];
                    for (var n in e) S.isFunction(e[n]) && t.push(n);
                    return t.sort()
                }, S.extend = function(e) {
                    return x(o.call(arguments, 1), function(t) {
                        for (var n in t) e[n] = t[n]
                    }), e
                }, S.pick = function(e) {
                    var t = {};
                    return x(S.flatten(o.call(arguments, 1)), function(n) {
                        n in e && (t[n] = e[n])
                    }), t
                }, S.defaults = function(e) {
                    return x(o.call(arguments, 1), function(t) {
                        for (var n in t) e[n] == null && (e[n] = t[n])
                    }), e
                }, S.clone = function(e) {
                    return S.isObject(e) ? S.isArray(e) ? e.slice() : S.extend({}, e) : e
                }, S.tap = function(e, t) {
                    return t(e), e
                }, S.isEqual = function(e, t) {
                    return C(e, t, [])
                }, S.isEmpty = function(e) {
                    if (e == null) return !0;
                    if (S.isArray(e) || S.isString(e)) return e.length === 0;
                    for (var t in e)
                        if (S.has(e, t)) return !1;
                    return !0
                }, S.isElement = function(e) {
                    return !!e && e.nodeType == 1
                }, S.isArray = b ||
                function(e) {
                    return a.call(e) == "[object Array]"
                }, S.isObject = function(e) {
                    return e === Object(e)
                }, S.isArguments = function(e) {
                    return a.call(e) == "[object Arguments]"
                }, S.isArguments(arguments) || (S.isArguments = function(e) {
                    return !!e && !!S.has(e, "callee")
                }), S.isFunction = function(e) {
                    return a.call(e) == "[object Function]"
                }, S.isString = function(e) {
                    return a.call(e) == "[object String]"
                }, S.isNumber = function(e) {
                    return a.call(e) == "[object Number]"
                }, S.isFinite = function(e) {
                    return S.isNumber(e) && isFinite(e)
                }, S.isNaN = function(e) {
                    return e !== e
                }, S.isBoolean = function(e) {
                    return e === !0 || e === !1 || a.call(e) == "[object Boolean]"
                }, S.isDate = function(e) {
                    return a.call(e) == "[object Date]"
                }, S.isRegExp = function(e) {
                    return a.call(e) == "[object RegExp]"
                }, S.isNull = function(e) {
                    return e === null
                }, S.isUndefined = function(e) {
                    return e === void 0
                }, S.has = function(e, t) {
                    return f.call(e, t)
                }, S.noConflict = function() {
                    return e._ = t, this
                }, S.identity = function(e) {
                    return e
                }, S.times = function(e, t, n) {
                    for (var r = 0; r < e; r++) t.call(n, r)
                }, S.escape = function(e) {
                    return ("" + e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;")
                }, S.result = function(e, t) {
                    if (e == null) return null;
                    var n = e[t];
                    return S.isFunction(n) ? n.call(e) : n
                }, S.mixin = function(e) {
                    x(S.functions(e), function(t) {
                        B(t, S[t] = e[t])
                    })
                };
            var k = 0;
            S.uniqueId = function(e) {
                var t = k++;
                return e ? e + t : t
            }, S.templateSettings = {
                evaluate: /<%([\s\S]+?)%>/g,
                interpolate: /<%=([\s\S]+?)%>/g,
                escape: /<%-([\s\S]+?)%>/g
            };
            var L = /.^/,
                A = {
                    "\\": "\\",
                    "'": "'",
                    r: "\r",
                    n: "\n",
                    t: "	",
                    u2028: "\u2028",
                    u2029: "\u2029"
                };
            for (var O in A) A[A[O]] = O;
            var M = /\\|'|\r|\n|\t|\u2028|\u2029/g,
                _ = /\\(\\|'|r|n|t|u2028|u2029)/g,
                D = function(e) {
                    return e.replace(_, function(e, t) {
                        return A[t]
                    })
                };
            S.template = function(e, t, n) {
                n = S.defaults(n || {}, S.templateSettings);
                var r = "__p+='" + e.replace(M, function(e) {
                    return "\\" + A[e]
                }).replace(n.escape || L, function(e, t) {
                    return "'+\n_.escape(" + D(t) + ")+\n'"
                }).replace(n.interpolate || L, function(e, t) {
                    return "'+\n(" + D(t) + ")+\n'"
                }).replace(n.evaluate || L, function(e, t) {
                    return "';\n" + D(t) + "\n;__p+='"
                }) + "';\n";
                n.variable || (r = "with(obj||{}){\n" + r + "}\n"), r = "var __p='';var print=function(){__p+=Array.prototype.join.call(arguments, '')};\n" + r + "return __p;\n";
                var i = new Function(n.variable || "obj", "_", r);
                if (t) return i(t, S);
                var s = function(e) {
                    return i.call(this, e, S)
                };
                return s.source = "function(" + (n.variable || "obj") + "){\n" + r + "}", s
            }, S.chain = function(e) {
                return S(e).chain()
            };
            var P = function(e) {
                this._wrapped = e
            };
            S.prototype = P.prototype;
            var H = function(e, t) {
                    return t ? S(e).chain() : e
                },
                B = function(e, t) {
                    P.prototype[e] = function() {
                        var e = o.call(arguments);
                        return u.call(e, this._wrapped), H(t.apply(S, e), this._chain)
                    }
                };
            S.mixin(S), x(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"], function(e) {
                var t = r[e];
                P.prototype[e] = function() {
                    var n = this._wrapped;
                    t.apply(n, arguments);
                    var r = n.length;
                    return (e == "shift" || e == "splice") && r === 0 && delete n[0], H(n, this._chain)
                }
            }), x(["concat", "join", "slice"], function(e) {
                var t = r[e];
                P.prototype[e] = function() {
                    return H(t.apply(this._wrapped, arguments), this._chain)
                }
            }), P.prototype.chain = function() {
                return this._chain = !0, this
            }, P.prototype.value = function() {
                return this._wrapped
            }
        }.call(this), n("lib/underscore", function(e) {
            return function() {
                return e._
            }
        }(this)),
        function(e) {
            function t(e, t, n, r, i) {
                this._listener = t, this._isOnce = n, this.context = r, this._signal = e, this._priority = i || 0
            }

            function r(e, t) {
                if (typeof e != "function") throw new Error("listener is a required param of {fn}() and should be a Function.".replace("{fn}", t))
            }

            function i() {
                this._bindings = [], this._prevParams = null
            }
            t.prototype = {
                active: !0,
                params: null,
                execute: function(e) {
                    var t, n;
                    return this.active && !!this._listener && (n = this.params ? this.params.concat(e) : e, t = this._listener.apply(this.context, n), this._isOnce && this.detach()), t
                },
                detach: function() {
                    return this.isBound() ? this._signal.remove(this._listener, this.context) : null
                },
                isBound: function() {
                    return !!this._signal && !!this._listener
                },
                getListener: function() {
                    return this._listener
                },
                _destroy: function() {
                    delete this._signal, delete this._listener, delete this.context
                },
                isOnce: function() {
                    return this._isOnce
                },
                toString: function() {
                    return "[SignalBinding isOnce:" + this._isOnce + ", isBound:" + this.isBound() + ", active:" + this.active + "]"
                }
            }, i.prototype = {
                VERSION: "0.8.1",
                memorize: !1,
                _shouldPropagate: !0,
                active: !0,
                _registerListener: function(e, n, r, i) {
                    var s = this._indexOfListener(e, r),
                        o;
                    if (s !== -1) {
                        o = this._bindings[s];
                        if (o.isOnce() !== n) throw new Error("You cannot add" + (n ? "" : "Once") + "() then add" + (n ? "Once" : "") + "() the same listener without removing the relationship first.")
                    } else o = new t(this, e, n, r, i), this._addBinding(o);
                    return this.memorize && this._prevParams && o.execute(this._prevParams), o
                },
                _addBinding: function(e) {
                    var t = this._bindings.length;
                    do --t;
                    while (this._bindings[t] && e._priority <= this._bindings[t]._priority);
                    this._bindings.splice(t + 1, 0, e)
                },
                _indexOfListener: function(e, t) {
                    var n = this._bindings.length,
                        r;
                    while (n--) {
                        r = this._bindings[n];
                        if (r._listener === e && r.context === t) return n
                    }
                    return -1
                },
                has: function(e, t) {
                    return this._indexOfListener(e, t) !== -1
                },
                add: function(e, t, n) {
                    return r(e, "add"), this._registerListener(e, !1, t, n)
                },
                addOnce: function(e, t, n) {
                    return r(e, "addOnce"), this._registerListener(e, !0, t, n)
                },
                remove: function(e, t) {
                    r(e, "remove");
                    var n = this._indexOfListener(e, t);
                    return n !== -1 && (this._bindings[n]._destroy(), this._bindings.splice(n, 1)), e
                },
                removeAll: function() {
                    var e = this._bindings.length;
                    while (e--) this._bindings[e]._destroy();
                    this._bindings.length = 0
                },
                getNumListeners: function() {
                    return this._bindings.length
                },
                halt: function() {
                    this._shouldPropagate = !1
                },
                dispatch: function(e) {
                    if (!this.active) return;
                    var t = Array.prototype.slice.call(arguments),
                        n = this._bindings.length,
                        r;
                    this.memorize && (this._prevParams = t);
                    if (!n) return;
                    r = this._bindings.slice(), this._shouldPropagate = !0;
                    do n--;
                    while (r[n] && this._shouldPropagate && r[n].execute(t) !== !1)
                },
                forget: function() {
                    this._prevParams = null
                },
                dispose: function() {
                    this.removeAll(), delete this._bindings, delete this._prevParams
                },
                toString: function() {
                    return "[Signal active:" + this.active + " numListeners:" + this.getNumListeners() + "]"
                }
            };
            var s = i;
            s.Signal = i, typeof n == "function" && n.amd ? n("lib/signals", [], function() {
                return s
            }) : typeof module != "undefined" && module.exports ? module.exports = s : e.signals = s
        }(this), n("class", ["require", "exports", "module"], function(e, t, n) {
            var r = !1,
                i = /xyz/.test(function() {
                    xyz
                }) ? /\b_super\b/ : /.*/,
                s = function() {},
                o = function(e) {
                    var t = this.prototype,
                        n = {};
                    for (var r in e) typeof e[r] == "function" && typeof t[r] == "function" && i.test(e[r]) ? (n[r] = t[r], t[r] = function(e, t) {
                        return function() {
                            var r = this._super;
                            this._super = n[e];
                            var i = t.apply(this, arguments);
                            return this._super = r, i
                        }
                    }(r, e[r])) : t[r] = e[r]
                };
            s.extend = function(e) {
                function u() {
                    !r && this.init && this.init.apply(this, arguments)
                }
                var t = this.prototype;
                r = !0;
                var n = new this;
                r = !1;
                for (var s in e) n[s] = typeof e[s] == "function" && typeof t[s] == "function" && i.test(e[s]) ?
                    function(e, n) {
                        return function() {
                            var r = this._super;
                            this._super = t[e];
                            var i = n.apply(this, arguments);
                            return this._super = r, i
                        }
                    }(s, e[s]) : e[s];
                return u.prototype = n, u.prototype.constructor = u, u.extend = arguments.callee, u.inject = o, u
            }, n.exports = s
        }), n("tween", ["require", "exports", "module"], function(e, t, n) {
            (function() {
                var e = 0,
                    t = ["ms", "moz", "webkit", "o"];
                for (var n = 0; n < t.length && !window.requestAnimationFrame; ++n) window.requestAnimationFrame = window[t[n] + "RequestAnimationFrame"], window.cancelAnimationFrame = window[t[n] + "CancelAnimationFrame"] || window[t[n] + "CancelRequestAnimationFrame"];
                window.requestAnimationFrame || (window.requestAnimationFrame = function(t, n) {
                    var r = (new Date).getTime(),
                        i = Math.max(0, 16 - (r - e)),
                        s = window.setTimeout(function() {
                            t(r + i)
                        }, i);
                    return e = r + i, s
                }), window.cancelAnimationFrame || (window.cancelAnimationFrame = function(e) {
                    clearTimeout(e)
                })
            })();
            var r = r ||
                function() {
                    var e = [];
                    return {
                        REVISION: "6",
                        getAll: function() {
                            return e
                        },
                        removeAll: function() {
                            e = []
                        },
                        add: function(t) {
                            e.push(t)
                        },
                        remove: function(t) {
                            var n = e.indexOf(t);
                            n !== -1 && e.splice(n, 1)
                        },
                        update: function(t) {
                            var n = 0,
                                r = e.length,
                                t = t !== undefined ? t : Date.now();
                            while (n < r) e[n].update(t) ? n++ : (e.splice(n, 1), r--)
                        }
                    }
                }();
            r.Tween = function(e) {
                    var t = e,
                        n = {},
                        i = {},
                        s = 1e3,
                        o = 0,
                        u = null,
                        a = r.Easing.Linear.None,
                        f = r.Interpolation.Linear,
                        l = null,
                        c = null,
                        h = null;
                    this.to = function(e, t) {
                        return t !== null && (s = t), i = e, this
                    }, this.start = function(e) {
                        r.add(this), u = e !== undefined ? e : Date.now(), u += o;
                        for (var s in i) {
                            if (t[s] === null) continue;
                            if (i[s] instanceof Array) {
                                if (i[s].length === 0) continue;
                                i[s] = [t[s]].concat(i[s])
                            }
                            n[s] = t[s]
                        }
                        return this
                    }, this.stop = function() {
                        return r.remove(this), this
                    }, this.delay = function(e) {
                        return o = e, this
                    }, this.easing = function(e) {
                        return a = e, this
                    }, this.interpolation = function(e) {
                        return f = e, this
                    }, this.chain = function(e) {
                        return l = e, this
                    }, this.onUpdate = function(e) {
                        return c = e, this
                    }, this.onComplete = function(e) {
                        return h = e, this
                    }, this.update = function(e) {
                        if (e < u) return !0;
                        var r = (e - u) / s;
                        r = r > 1 ? 1 : r;
                        var o = a(r);
                        for (var p in n) {
                            var d = n[p],
                                v = i[p];
                            v instanceof Array ? t[p] = f(v, o) : t[p] = d + (v - d) * o
                        }
                        return c !== null && c.call(t, o), r == 1 ? (h !== null && h.call(t), l !== null && l.start(), !1) : !0
                    }
                }, r.Easing = {
                    Linear: {
                        None: function(e) {
                            return e
                        }
                    },
                    Quadratic: {
                        In: function(e) {
                            return e * e
                        },
                        Out: function(e) {
                            return e * (2 - e)
                        },
                        InOut: function(e) {
                            return (e *= 2) < 1 ? .5 * e * e : -0.5 * (--e * (e - 2) - 1)
                        }
                    },
                    Cubic: {
                        In: function(e) {
                            return e * e * e
                        },
                        Out: function(e) {
                            return --e * e * e + 1
                        },
                        InOut: function(e) {
                            return (e *= 2) < 1 ? .5 * e * e * e : .5 * ((e -= 2) * e * e + 2)
                        }
                    },
                    Quartic: {
                        In: function(e) {
                            return e * e * e * e
                        },
                        Out: function(e) {
                            return 1 - --e * e * e * e
                        },
                        InOut: function(e) {
                            return (e *= 2) < 1 ? .5 * e * e * e * e : -0.5 * ((e -= 2) * e * e * e - 2)
                        }
                    },
                    Quintic: {
                        In: function(e) {
                            return e * e * e * e * e
                        },
                        Out: function(e) {
                            return --e * e * e * e * e + 1
                        },
                        InOut: function(e) {
                            return (e *= 2) < 1 ? .5 * e * e * e * e * e : .5 * ((e -= 2) * e * e * e * e + 2)
                        }
                    },
                    Sinusoidal: {
                        In: function(e) {
                            return 1 - Math.cos(e * Math.PI / 2)
                        },
                        Out: function(e) {
                            return Math.sin(e * Math.PI / 2)
                        },
                        InOut: function(e) {
                            return .5 * (1 - Math.cos(Math.PI * e))
                        }
                    },
                    Exponential: {
                        In: function(e) {
                            return e === 0 ? 0 : Math.pow(1024, e - 1)
                        },
                        Out: function(e) {
                            return e === 1 ? 1 : 1 - Math.pow(2, -10 * e)
                        },
                        InOut: function(e) {
                            return e === 0 ? 0 : e === 1 ? 1 : (e *= 2) < 1 ? .5 * Math.pow(1024, e - 1) : .5 * (-Math.pow(2, -10 * (e - 1)) + 2)
                        }
                    },
                    Circular: {
                        In: function(e) {
                            return 1 - Math.sqrt(1 - e * e)
                        },
                        Out: function(e) {
                            return Math.sqrt(1 - --e * e)
                        },
                        InOut: function(e) {
                            return (e *= 2) < 1 ? -0.5 * (Math.sqrt(1 - e * e) - 1) : .5 * (Math.sqrt(1 - (e -= 2) * e) + 1)
                        }
                    },
                    Elastic: {
                        In: function(e) {
                            var t, n = .1,
                                r = .4;
                            return e === 0 ? 0 : e === 1 ? 1 : (!n || n < 1 ? (n = 1, t = r / 4) : t = r * Math.asin(1 / n) / (2 * Math.PI), -(n * Math.pow(2, 10 * (e -= 1)) * Math.sin((e - t) * 2 * Math.PI / r)))
                        },
                        Out: function(e) {
                            var t, n = 2,
                                r = .4;
                            return e === 0 ? 0 : e === 1 ? 1 : (!n || n < 1 ? (n = 1, t = r / 4) : t = r * Math.asin(1 / n) / (2 * Math.PI), n * Math.pow(2, -10 * e) * Math.sin((e - t) * 2 * Math.PI / r) + 1)
                        },
                        InOut: function(e) {
                            var t, n = .1,
                                r = .4;
                            return e === 0 ? 0 : e === 1 ? 1 : (!n || n < 1 ? (n = 1, t = r / 4) : t = r * Math.asin(1 / n) / (2 * Math.PI), (e *= 2) < 1 ? -0.5 * n * Math.pow(2, 10 * (e -= 1)) * Math.sin((e - t) * 2 * Math.PI / r) : n * Math.pow(2, -10 * (e -= 1)) * Math.sin((e - t) * 2 * Math.PI / r) * .5 + 1)
                        }
                    },
                    Back: {
                        In: function(e) {
                            var t = 1.70158;
                            return e * e * ((t + 1) * e - t)
                        },
                        Out: function(e) {
                            var t = 1.70158;
                            return --e * e * ((t + 1) * e + t) + 1
                        },
                        InOut: function(e) {
                            var t = 2.5949095;
                            return (e *= 2) < 1 ? .5 * e * e * ((t + 1) * e - t) : .5 * ((e -= 2) * e * ((t + 1) * e + t) + 2)
                        }
                    },
                    Bounce: {
                        In: function(e) {
                            return 1 - r.Easing.Bounce.Out(1 - e)
                        },
                        Out: function(e) {
                            return e < 1 / 2.75 ? 7.5625 * e * e : e < 2 / 2.75 ? 7.5625 * (e -= 1.5 / 2.75) * e + .75 : e < 2.5 / 2.75 ? 7.5625 * (e -= 2.25 / 2.75) * e + .9375 : 7.5625 * (e -= 2.625 / 2.75) * e + .984375
                        },
                        InOut: function(e) {
                            return e < .5 ? r.Easing.Bounce.In(e * 2) * .5 : r.Easing.Bounce.Out(e * 2 - 1) * .5 + .5
                        }
                    }
                }, r.Interpolation = {
                    Linear: function(e, t) {
                        var n = e.length - 1,
                            i = n * t,
                            s = Math.floor(i),
                            o = r.Interpolation.Utils.Linear;
                        return t < 0 ? o(e[0], e[1], i) : t > 1 ? o(e[n], e[n - 1], n - i) : o(e[s], e[s + 1 > n ? n : s + 1], i - s)
                    },
                    Bezier: function(e, t) {
                        var n = 0,
                            i = e.length - 1,
                            s = Math.pow,
                            o = r.Interpolation.Utils.Bernstein,
                            u;
                        for (u = 0; u <= i; u++) n += s(1 - t, i - u) * s(t, u) * e[u] * o(i, u);
                        return n
                    },
                    CatmullRom: function(e, t) {
                        var n = e.length - 1,
                            i = n * t,
                            s = Math.floor(i),
                            o = r.Interpolation.Utils.CatmullRom;
                        return e[0] === e[n] ? (t < 0 && (s = Math.floor(i = n * (1 + t))), o(e[(s - 1 + n) % n], e[s], e[(s + 1) % n], e[(s + 2) % n], i - s)) : t < 0 ? e[0] - (o(e[0], e[0], e[1], e[1], -i) - e[0]) : t > 1 ? e[n] - (o(e[n], e[n], e[n - 1], e[n - 1], i - n) - e[n]) : o(e[s ? s - 1 : 0], e[s], e[n < s + 1 ? n : s + 1], e[n < s + 2 ? n : s + 2], i - s)
                    },
                    Utils: {
                        Linear: function(e, t, n) {
                            return (t - e) * n + e
                        },
                        Bernstein: function(e, t) {
                            var n = r.Interpolation.Utils.Factorial;
                            return n(e) / n(t) / n(e - t)
                        },
                        Factorial: function() {
                            var e = [1];
                            return function(t) {
                                var n = 1,
                                    r;
                                if (e[t]) return e[t];
                                for (r = t; r > 1; r--) n *= r;
                                return e[t] = n
                            }
                        }(),
                        CatmullRom: function(e, t, n, r, i) {
                            var s = (n - e) * .5,
                                o = (r - t) * .5,
                                u = i * i,
                                a = i * u;
                            return (2 * t - 2 * n + s + o) * a + (-3 * t + 3 * n - 2 * s - o) * u + s * i + t
                        }
                    }
                },
                function i() {
                    requestAnimationFrame(i), r.update()
                }(), n.exports = r
        }), n("item", ["require", "exports", "module", "./lib/underscore", "./lib/signals", "./class", "./tween"], function(e, t, n) {
            function a(e) {
                return ["translate(", e.x, ",", e.y, ") rotate(", e.r, ") scale(", e.s, ")"].join("")
            }

            function f() {
                this.node.setAttribute("transform", a(this.transform))
            }
            var r = e("./lib/underscore"),
                i = e("./lib/signals"),
                s = e("./class"),
                o = e("./tween"),
                u = {
                    transformAnimDuration: 500,
                    transformAnimTween: o.Easing.Elastic.Out
                },
                l = s.extend({
                    id: null,
                    type: null,
                    node: null,
                    parent: null,
                    manager: null,
                    init: function(e) {
                        this.transform = {
                            x: 0,
                            y: 0,
                            r: 0,
                            s: 1
                        }, this.on = {
                            add: new i,
                            remove: new i
                        }, e && (this.id = e.id || null), this.elements = {}, this.tweens = {}, this.settings = {}, this._bbox = {
                            width: 0,
                            height: 0
                        }, this.tweens.transform = (new o.Tween(this.transform)).easing(o.Easing.Elastic.Out).onUpdate(r.bind(f, this))
                    },
                    remove: function() {
                        r.isNull(this.id) || r.isNull(this.node) || r.isNull(this.parent) || (this.onRemove(this), this.parent && this.parent.node.removeChild(this.node), delete this)
                    },
                    pos: function(e, t) {
                        return this.tweens.transform.stop(), this.transform.x = e, this.transform.y = t, this.node.setAttribute("transform", a(this.transform)), this
                    },
                    posAnim: function(e, t, n, r) {
                        return this.tweens.transform.stop().to({
                            x: e,
                            y: t
                        }, n || u.transformAnimDuration).easing(r || u.transformAnimTween).start(), this
                    },
                    invalidate: function() {
                        r.defer(function(e) {
                            var t = e.node.getBoundingClientRect();
                            e._bbox.width = t.width, e._bbox.height = t.height
                        }, this)
                    },
                    getBoundingBox: function() {
                        return {
                            x: this.transform.x,
                            y: this.transform.y,
                            w: this._bbox.width,
                            h: this._bbox.height
                        }
                    },
                    onAdd: function() {
                        this.on.add.dispatch(this)
                    },
                    onRemove: function() {
                        this.on.remove.dispatch(this)
                    }
                });
            n.exports = l
        }), n("drag", ["require", "exports", "module", "./lib/underscore", "./lib/signals"], function(e, t, n) {
            function o(e, t) {
                var n = new RegExp("\\b" + t + "\\b");
                return e.getAttribute ? n.test(e.getAttribute("class")) : !1
            }

            function u(e, t, n) {
                var r = e.getBoundingClientRect();
                return {
                    x: t - r.left,
                    y: n - r.top
                }
            }

            function a(e, t) {
                while (e && (!o(e, t) || !e.id)) e = e.parentNode;
                if (e) return e
            }

            function f(e) {
                if (r.isUndefined(e.drag)) return;
                e.dragManager = this, e.drag.handle.addEventListener("mousedown", r.bind(h, {
                    manager: this,
                    item: e
                }))
            }

            function l() {
                var e = this._drag.item;
                if (r.isNull(e)) return;
                e.node.style.display = "none";
                var t = document.elementFromPoint(this._drag.cx, this._drag.cy),
                    n = a(t, "droppable"),
                    i = this.getDropableItem(n ? n.id : "");
                r.isUndefined(i) || (this._drag.dropItem != i && this._drag.dropItem && this._drag.dropItem.dragOut(e, this._drag.x, this._drag.y), this._drag.dropItem = i, i.dragOver(e, this._drag.x, this._drag.y)), e.node.style.display = "", this._drag.dragCheckTimer = null
            }

            function c(e, t) {
                var n = this._drag.item;
                if (r.isNull(n)) return;
                n.node.style.display = "none";
                var i = document.elementFromPoint(this._drag.cx, this._drag.cy),
                    s = a(i, "droppable"),
                    o = this.getDropableItem(s.id);
                if (!r.isUndefined(o)) {
                    var u = o.dropIn(n, e, t);
                    u || this._drag.itemStartDrag.parent.dropIn(n, this._drag.itemStartDrag.x, this._drag.itemStartDrag.y, !0)
                }
                n.node.style.display = ""
            }

            function h(e) {
                e.preventDefault();
                if (!this.item.drag.enabled || !r.isNull(this.manager._drag.item)) return;
                var t = u(this.manager.parent, e.clientX, e.clientY);
                this.manager._drag.item = this.item, this.manager._drag.x = t.x, this.manager._drag.y = t.y
            }

            function p(e) {
                e.preventDefault();
                if (r.isNull(this._drag.item)) return;
                var t = this._drag.item,
                    n = u(this.parent, e.clientX, e.clientY);
                cx = e.clientX, cy = e.clientY;
                if (!this._drag.dragging && Math.pow(this._drag.x - n.x, 2) + Math.pow(this._drag.y - n.y, 2) < Math.pow(t.drag.distance, 2)) return;
                this._drag.dragging || (this._drag.dragging = !0, t.parent.node.removeChild(t.node), t.parent.node.appendChild(t.node), t.parent.drop && (this._drag.itemStartDrag.parent = t.parent, this._drag.itemStartDrag.x = n.x, this._drag.itemStartDrag.y = n.y, t.parent.dropOut(t, n.x, n.y)), this._drag.cursor = this.node.style.cursor, this.node.style.cursor = "move", this.dragStart(t, n.x, n.y), t.dragStart(n.x, n.y), t.drag.dragging = !0);
                var i = n.x - this._drag.x,
                    o = n.y - this._drag.y,
                    a = t.transform.x + i,
                    f = t.transform.y + o;
                if (t.drag.boundingBox) {
                    var c = t.getBoundingBox();
                    c.x + i < 0 ? a = 0 : c.x + i + c.w > this.parent.offsetWidth && (a = this.parent.offsetWidth - c.w), c.y + o < 0 ? f -= c.y + o : c.y + o + c.h > this.parent.offsetHeight && (f += this.parent.offsetHeight - (c.y + o + c.h))
                }
                t.pos(a, f), this._drag.x = n.x, this._drag.y = n.y, this._drag.cx = cx, this._drag.cy = cy, t.drag.checkDragOver && r.isNull(this._drag.dragCheckTimer) && (this._drag.dragCheckTimer = setTimeout(r.bind(l, this), s.checkDragOverDelay)), this.drag(t, n.x, n.y), t.dragMove(n.x, n.y)
            }

            function d(e) {
                e.preventDefault();
                if (r.isNull(this._drag.item)) return;
                if (this._drag.dragging) {
                    var t = this._drag.item,
                        n = u(this.parent, e.clientX, e.clientY);
                    xd = n.x - this._drag.x, yd = n.y - this._drag.y, newposx = t.transform.x + xd, newposy = t.transform.y + yd, t.pos(newposx, newposy), t.drag.dragging = !1, this.node.style.cursor = this._drag.cursor, t.drag.checkDropOver && c.call(this, n.x, n.y), this.dragEnd(t, n.x, n.y), t.dragEnd(n.x, n.y)
                }
                this._drag = {
                    item: null,
                    x: null,
                    y: null,
                    dragging: !1,
                    dragCheckTimer: null,
                    itemStartDrag: {
                        parent: null,
                        x: 0,
                        y: 0
                    }
                }
            }
            var r = e("./lib/underscore"),
                i = e("./lib/signals"),
                s = {
                    checkDragOverDelay: 16
                };
            n.exports = {
                asDragElement: function(e) {
                    this.drag = r.extend({
                        handle: this.node,
                        distance: 5,
                        enabled: !0,
                        dragging: !1,
                        checkDragOver: !0,
                        checkDropOver: !0,
                        boundingBox: !0
                    }, e || {}), r.defaults(this, {
                        dragStart: function(e, t) {},
                        dragEnd: function(e, t) {},
                        dragMove: function(e, t) {}
                    })
                },
                asDropElement: function(e) {
                    this.drop = r.extend({
                        handle: this.node,
                        enabled: !0
                    }, e || {}), this.drop.handle.className.baseVal += " droppable", r.defaults(this, {
                        dragOver: function(e, t, n) {},
                        dragOut: function(e, t, n) {},
                        dropIn: function(e, t, n) {},
                        dropOut: function(e, t, n) {}
                    })
                },
                asDragManager: function(e) {
                    this.on.addItem.add(r.bind(f, this)), r.defaults(this, {
                        _drag: {
                            item: null,
                            x: null,
                            y: null,
                            dragging: !1,
                            dragCheckTimer: null,
                            dropItem: null,
                            cursor: "default",
                            itemStartDrag: {
                                parent: null,
                                x: 0,
                                y: 0
                            }
                        },
                        dragStart: function(e, t, n) {},
                        dragEnd: function(e, t, n) {},
                        drag: function(e, t, n) {},
                        getDropableItem: function() {},
                        registerDragItem: function(e) {
                            f.call(this, e)
                        }
                    }), e.addEventListener("mousemove", r.bind(p, this)), e.addEventListener("mouseup", r.bind(d, this))
                }
            }
        }), n("grid", ["require", "exports", "module", "./lib/underscore", "./class"], function(e, t, n) {
            var r = e("./lib/underscore"),
                i = e("./class"),
                s = i.extend({
                    init: function() {
                        this._grid = []
                    },
                    setValue: function(e, t, n) {
                        this._grid[t] || (this._grid[t] = []), this._grid[t][e] || (this._grid[t][e] = []), this._grid[t][e].push(n)
                    },
                    removeValue: function(e, t, n) {
                        if (!this._grid[t] || !this._grid[t][e]) return null;
                        this._grid[t][e].splice(this._grid[t][e].indexOf(n), 1)
                    },
                    getValue: function(e, t) {
                        return !this._grid[t] || !this._grid[t][e] ? null : this._grid[t][e][this._grid[t][e].length - 1] || null
                    },
                    getValues: function(e, t) {
                        return !this._grid[t] || !this._grid[t][e] ? null : this._grid[t][e] || null
                    },
                    getRowCount: function() {
                        var e = [];
                        return r.each(this._grid, function(t, n) {
                            r.any(t, function(e) {
                                return r.size(e) > 0
                            }) ? e.push(n + 1) : e.push(0)
                        }), r.max(e) || 0
                    },
                    getColumnCount: function() {
                        var e = [];
                        return r.each(this._grid, function(t) {
                            r.each(t, function(t, n) {
                                r.size(t) > 0 && e.push(n + 1)
                            })
                        }), r.max(e) || 0
                    }
                });
            n.exports = s
        }), n("core", ["require", "exports", "module", "./lib/underscore", "./lib/signals", "./class", "./tween", "./item", "./drag", "./grid"], function(e, t, n) {
            function d(e) {
                e.onmousedown = function() {
                    return !1
                }, e.style.cursor = "default"
            }

            function v() {
                var e = -1;
                if (navigator.appName == "Microsoft Internet Explorer") {
                    var t = navigator.userAgent,
                        n = new RegExp("MSIE ([0-9]{1,}[.0-9]{0,})");
                    n.exec(t) != null && (e = parseFloat(RegExp.$1))
                }
                return e
            }

            function g(e, t, n, r, i) {
                var s = document.createElementNS(l, "rect");
                return S(s, e, t, n, r), s.setAttribute("fill", "rgba(255,255,255,1)"), s.style.opacity = .6, this.layers.indicatorLayer.appendChild(s), i || y(s), s
            }

            function y(e) {
                var t = function() {
                    var n = parseFloat(e.style.opacity) - .04;
                    e.style.opacity = n, n > 0 ? setTimeout(t, 10) : e.parentNode.removeChild(e)
                };
                t()
            }

            function b(e) {
                e && (e.on.remove.remove(b), this.grid.removeValue(e.settings.gridX, e.settings.gridY, e), this.items[e.id] = null, delete this.items[e.id])
            }

            function E(e) {
                return document.createElementNS(l, e)
            }

            function S(e, t, n, r, i) {
                e.setAttribute("x", t), e.setAttribute("y", n), e.setAttribute("width", r), e.setAttribute("height", i)
            }

            function x(e, t, n, r, i, s, o, u) {
                var a = [];
                return a = a.concat(["M", e, i + t, "Q", e, t, e + i, t]), a = a.concat(["L", e + n - s, t, "Q", e + n, t, e + n, t + s]), a = a.concat(["L", e + n, t + r - o, "Q", e + n, t + r, e + n - o, t + r]), a = a.concat(["L", e + u, t + r, "Q", e, t + r, e, t + r - u, "Z"]), a.join(" ")
            }

            function T(e, t, n, r, i) {
                var s = [];
                return s = s.concat(["M", 0, (r - i) / 2, "L", (n - i) / 2, (r - i) / 2]), s = s.concat(["L", (n - i) / 2, 0, "L", (n + i) / 2, 0]), s = s.concat(["L", (n + i) / 2, (r - i) / 2, "L", n, (r - i) / 2]), s = s.concat(["L", n, (r + i) / 2, "L", (n + i) / 2, (r + i) / 2]), s = s.concat(["L", (n + i) / 2, r, "L", (n - i) / 2, r]), s = s.concat(["L", (n - i) / 2, (r + i) / 2, "L", 0, (r + i) / 2, "Z"]), s.join(" ")
            }

            function N(e, t) {
                return e.className.baseVal.match(new RegExp("(\\s|^)" + t + "(\\s|$)"))
            }

            function C(e, t) {
                N(e, t) || (e.className.baseVal += " " + t)
            }

            function k(e, t) {
                if (N(e, t)) {
                    var n = new RegExp("(\\s|^)" + t + "(\\s|$)");
                    e.className = e.className.baseVal.replace(n, " ")
                }
            }
            var r = e("./lib/underscore"),
                i = e("./lib/signals"),
                s = e("./class"),
                o = e("./tween"),
                u = e("./item"),
                a = e("./drag"),
                f = e("./grid"),
                l = "http://www.w3.org/2000/svg",
                c = 1,
                h = "jtop_desktop",
                p = "DESKTOP",
                m = {
                    create: new i
                },
                w = s.extend({
                    init: function(e, t) {
                        var n = h + "_" + c++,
                            s, o, u;
                        this._settings = r.extend({
                            gridW: 100,
                            gridH: 100
                        }, t), r.isString(e) ? s = document.getElementById(e) : r.isElement(e) && (s = e);
                        if (r.isNull(s)) {
                            console.error("Cannot create desktop. Specified DOM element does not exists.");
                            return
                        }
                        o = document.createElementNS(l, "svg"), o.setAttribute("xlmns", l), o.setAttribute("xmlns:xlink", l), o.setAttribute("id", n), o.style.width = "100%", o.style.height = "100%", s.appendChild(o), u = document.createElementNS(l, "g"), u.setAttribute("class", "indicator-layer"), o.appendChild(u), d(s), this.id = n, this.node = o, this.parent = s, this.items = {}, this.type = p, this.grid = new f, this.on = {
                            addItem: new i,
                            removeItem: new i,
                            settings: new i,
                            change: new i,
                            dragOverItem: new i,
                            dragOutItem: new i,
                            dropInItem: new i,
                            dragStart: new i,
                            dragEnd: new i
                        }, this.layers = {
                            indicatorLayer: u
                        }, a.asDragManager.call(this, o), a.asDropElement.call(this), this._drag.gridX = -1, this._drag.gridY = -1, m.create.dispatch(this)
                    },
                    addItem: function(e, t, n) {
                        if (e instanceof u && r.isString(e.type) && !r.has(this.items, e.id)) {
                            var i = this._settings;
                            return e.id = e.id || r.uniqueId("jtop_" + e.type + "_"), this.items[e.id] = e, r.isElement(e.node) && (C(e.node, "ITEM"), C(e.node, e.type), e.node.setAttribute("id", e.id), e.parent = this, e.manager = this, e.on.remove.add(b, this), this.node.appendChild(e.node)), r.isNumber(t) && r.isNumber(n) && (this.grid.setValue(t, n, e), e.settings.gridX = t, e.settings.gridY = n, e.pos(e.settings.gridX * i.gridW, e.settings.gridY * i.gridH)), this.on.addItem.dispatch(e), e.onAdd.call(e, this), e
                        }
                    },
                    removeItem: function(e) {
                        var t;
                        r.has(this.items, e) ? t = this.items[e] : e instanceof u && (t = e), t && t.remove()
                    },
                    dragStart: function(e, t, n) {
                        if (!r.has(this.items, e.id)) return;
                        this.on.dragStart.dispatch(e, t, n), e.type === "ICON" && (e.parent.id !== this.id && e.pos(e.transform.x + e.parent.transform.x, e.transform.y + e.parent.transform.y), e.parent.node.removeChild(e.node), e.parent = this, e.parent.node.appendChild(e.node))
                    },
                    dragEnd: function(e, t, n) {
                        if (!r.has(this.items, e.id)) return;
                        this.on.dragEnd.dispatch(e, t, n)
                    },
                    dragOver: function(e, t, n) {
                        if (e.type === "ICON") {
                            var r = this,
                                i = this._settings,
                                s = Math.floor(t / i.gridW),
                                o = Math.floor(n / i.gridH);
                            if (s !== this._drag.gridX || o !== this._drag.gridY) {
                                this.on.dragOutItem.dispatch(e);
                                var u = this.grid.getValue(s, o);
                                u && this.on.dragOverItem.dispatch(e, u, t, n), g.call(r, s * i.gridW, o * i.gridH, i.gridW, i.gridH), this._drag.gridX = s, this._drag.gridY = o
                            }
                        }
                    },
                    dragOut: function(e, t, n) {
                        this.on.dragOutItem.dispatch(e), this._drag.gridX = -1, this._drag.gridY = -1
                    },
                    dropIn: function(e, t, n, r) {
                        if (e.type === "ICON") {
                            var i = this._settings,
                                s = this.grid,
                                u = Math.floor(t / i.gridW),
                                a = Math.floor(n / i.gridH),
                                f = this.grid.getValue(u, a);
                            return s.setValue(u, a, e), e.settings.gridX = u, e.settings.gridY = a, r ? e.posAnim(u * i.gridW, a * i.gridH, 150, o.Easing.Linear.None) : (e.posAnim(u * i.gridW, a * i.gridH), f && this.on.dropInItem.dispatch(e, f)), !0
                        }
                    },
                    dropOut: function(e, t, n) {
                        if (e.type === "ICON") {
                            var r = this._settings,
                                i = this.grid;
                            i.removeValue(e.settings.gridX, e.settings.gridY, e)
                        }
                    },
                    getDropableItem: function(e) {
                        return this.id === e ? this : this.getItemById(e)
                    },
                    getItemById: function(e) {
                        if (r.has(this.items, e)) return this.items[e]
                    },
                    settings: function(e) {
                        r.extend(this._settings, e), this.on.settings.dispatch(this._settings)
                    },
                    destroy: function() {
                        this.parent.removeChild(this.node)
                    }
                });
            n.exports = {
                Core: w,
                on: m,
                getIEVersion: v,
                svgSetXYWH: S,
                createSVGElement: E,
                addClass: C,
                hasClass: N,
                removeClass: k,
                path: {
                    roundedRectangle: x,
                    cross: T
                }
            }
        }), n("text", ["require", "exports", "module", "./core"], function(e, t, n) {
            function s(e, t, n) {
                e.textContent = t;
                var r = e.getComputedTextLength();
                if (r > n) {
                    var i = 1;
                    e.textContent = "";
                    while (e.getComputedTextLength() < n && i < t.length) e.textContent = t.substr(0, i) + "...", i++;
                    return e.textContent
                }
                return e.textContent = t, t
            }

            function o(e, t, n, o, a, f, l, c) {
                t.textContent = "";
                var h = [],
                    p = !0,
                    d = 0,
                    v = 0;
                while (p == 1) {
                    var m = e.indexOf("-", d);
                    m == -1 ? p = !1 : (h.push(m), d = m + 1)
                }
                var g = e.split(/[\s-]/),
                    y = "",
                    b = 0,
                    w = 0,
                    E = 0,
                    S = 0,
                    x, T, N = 0;
                for (i = 0; i < g.length; i++) {
                    var C = g[i];
                    E += C.length + 1;
                    if (S > n || i == 0) {
                        if (S > n) {
                            var k = T.firstChild.nodeValue;
                            k = k.slice(0, k.length - g[i - 1].length - 2), T.firstChild.nodeValue = k;
                            if (f) {
                                var L = k.split(/\s/).length;
                                S = T.getComputedTextLength();
                                var A = (n - S) / (L - 1);
                                T.setAttributeNS(null, "word-spacing", A)
                            }
                        }
                        w++, T = r.createSVGElement("tspan"), T.setAttributeNS(null, "x", o), T.setAttributeNS(null, "dy", b), x = document.createTextNode(y), T.appendChild(x), t.appendChild(T), u(h, E - 1) ? y = C + "-" : y = C + " ", i != 0 && (y = g[i - 1] + " " + y), b = a, v += b
                    } else u(h, E - 1) ? y += C + "-" : y += C + " ";
                    T.firstChild.nodeValue = y;
                    if (l && w >= l) {
                        c === !0 && (y = y.slice(0, -1), i < g.length - 1 && (y += " " + C), s(T, y, n));
                        return
                    }
                    S = T.getComputedTextLength();
                    if (i == g.length - 1 && S > n) {
                        var k = T.firstChild.nodeValue;
                        T.firstChild.nodeValue = k.slice(0, k.length - g[i].length - 1), T = r.createSVGElement("tspan"), T.setAttributeNS(null, "x", o), T.setAttributeNS(null, "dy", b), x = document.createTextNode(g[i]), T.appendChild(x), t.appendChild(T)
                    }
                }
                return v
            }

            function u(e, t) {
                var n = !1;
                for (var r = 0; r < e.length; r++) e[r] == t && (n = !0);
                return n
            }
            var r = e("./core");
            n.exports = {
                addTextFlow: o,
                addEllipseText: s
            }
        }), n("item.icon", ["require", "exports", "module", "./lib/underscore", "./lib/signals", "./core", "./item", "./text", "./drag", "./tween"], function(e, t, n) {
            function p() {
                var e = this.node,
                    t = this.elements.icon,
                    n = this.elements.title,
                    r = this.elements.handle,
                    i = this.elements._titleTop,
                    o = this.elements._titleShadow,
                    a = this.settings;
                t.setAttribute("x", (a.maxWidth - a.width) / 2), t.setAttribute("y", a.offsetTop);
                var f = t.getBBox();
                t.cx = a.maxWidth / 2, t.cy = a.offsetTop + a.height / 2, n.setAttribute("transform", "translate(" + (a.maxWidth / 2 - 1) + ", " + (f.height + f.y + a.fontSize + a.textOffsetTop) + ")"), u.addTextFlow(a.title, i, a.maxWidth - a.titleMargin * 2, 0, a.fontSize, !1, a.titleMaxLines, !0), u.addTextFlow(a.title, o, a.maxWidth - a.titleMargin * 2, 0, a.fontSize, !1, a.titleMaxLines, !0);
                var l = e.getBBox();
                s.svgSetXYWH(r, 0, 0, a.maxWidth, l.height)
            }

            function d() {
                var e = this.elements.icon;
                this.tweens.hover.stop().to({
                    r: h.mouseOverRotation
                }, h.mouseOverSpeed).start(), this.drag.dragging || (this.manager.node.style.cursor = "pointer")
            }

            function v() {
                var e = this.elements.icon;
                this.tweens.hover.stop().to({
                    r: h.mouseOutRotation
                }, h.mouseOutSpeed).start(), this.drag.dragging || (this.manager.node.style.cursor = "default")
            }

            function m(e) {
                this.on.click.dispatch(this, e)
            }
            var r = e("./lib/underscore"),
                i = e("./lib/signals"),
                s = e("./core"),
                o = e("./item"),
                u = e("./text"),
                a = e("./drag"),
                f = e("./tween"),
                l = "http://www.w3.org/1999/xlink",
                c = "ICON",
                h = {
                    fontFamily: '"Lucida Grande", "Lucida Sans Unicode", Helvetica, Arial, Verdana',
                    fontSize: 11,
                    mouseOverSpeed: 100,
                    mouseOutSpeed: 100,
                    mouseOverRotation: 10,
                    mouseOutRotation: 0,
                    titleMargin: 5,
                    titleMaxLines: 2
                },
                g = o.extend({
                    init: function(e) {
                        this._super(e);
                        var t = this.settings = r.extend({
                            image: "",
                            title: "",
                            width: 38,
                            height: 38,
                            maxWidth: 100,
                            maxHeight: 80,
                            offsetTop: 12,
                            textOffsetTop: 2,
                            fontFamily: h.fontFamily,
                            fontSize: h.fontSize,
                            titleMargin: h.titleMargin,
                            titleMaxLines: h.titleMaxLines
                        }, e);
                        this.type = c, r.extend(this.on, {
                            click: new i
                        });
                        var n = s.createSVGElement("g"),
                            o = s.createSVGElement("image"),
                            u = s.createSVGElement("g"),
                            f = s.createSVGElement("rect"),
                            p = s.createSVGElement("text"),
                            g = s.createSVGElement("text");
                        o.setAttributeNS(l, "xlink:href", t.image), o.setAttribute("width", t.width), o.setAttribute("height", t.height), p.setAttribute("font-family", t.fontFamily), p.setAttribute("font-size", t.fontSize), p.setAttribute("fill", "#FFF"), p.setAttribute("text-anchor", "middle"), g.setAttribute("font-family", t.fontFamily), g.setAttribute("font-size", t.fontSize), g.setAttribute("fill", "#000"), g.setAttribute("stroke", "#000"), g.setAttribute("stroke-width", 2.6), g.setAttribute("stroke-opacity", .5), g.setAttribute("text-anchor", "middle"), g.setAttribute("transform", "translate(1, 1)"), u.setAttribute("class", "text"), u.style["-webkit-user-select"] = "none", u.style["-moz-user-select"] = "none", u.appendChild(g), u.appendChild(p), f.setAttribute("fill", "#FFF"), f.setAttribute("opacity", "0.0"), f.setAttribute("rx", "5"), f.setAttribute("ry", "5"), n.appendChild(o), n.appendChild(u), n.appendChild(f), n.addEventListener("mouseover", r.bind(d, this)), n.addEventListener("mouseout", r.bind(v, this)), n.addEventListener("click", r.bind(m, this)), this.node = n, this.elements = {
                            icon: o,
                            title: u,
                            handle: f,
                            _titleTop: p,
                            _titleShadow: g
                        }, a.asDragElement.call(this)
                    },
                    title: function(e) {
                        return r.isString(e) && (this.settings.title = e, this.invalidate()), this
                    },
                    image: function(e) {
                        return r.isString(e) && (this.settings.image = e, this.elements.icon.setAttributeNS(l, "xlink:href", e)), this
                    },
                    onAdd: function(e) {
                        this.invalidate();
                        var t = this.elements.icon;
                        this.tweens.hover = (new f.Tween({
                            r: 0
                        })).easing(f.Easing.Linear.None).onUpdate(function() {
                            t.rotate = this.r, t.setAttribute("transform", "rotate(" + t.rotate + ", " + t.cx + "," + t.cy + ")")
                        }), this._super()
                    },
                    invalidate: function() {
                        p.call(this), this._super()
                    },
                    dragStart: function() {
                        this.node.style.opacity = .8
                    },
                    dragEnd: function() {
                        this.node.style.opacity = 1
                    }
                });
            s.Core.inject({
                icon: function(e) {
                    return this.addItem(new g(e), e.gridX, e.gridY)
                }
            }), n.exports = g
        }), n("offset", ["require", "exports", "module"], function(e, t, n) {
            function r(e) {
                var t, n, r = {
                        top: 0,
                        left: 0
                    },
                    s = e,
                    o = s && s.ownerDocument;
                if (!o) return;
                return t = o.documentElement, typeof s.getBoundingClientRect != "undefined" && (r = s.getBoundingClientRect()), n = i(o), {
                    top: r.top + (n.pageYOffset || t.scrollTop) - (t.clientTop || 0),
                    left: r.left + (n.pageXOffset || t.scrollLeft) - (t.clientLeft || 0)
                }
            }

            function i(e) {
                return e.nodeType === 9 ? e.defaultView || e.parentWindow : !1
            }
            n.exports = r
        }), n("item.panel", ["require", "exports", "module", "./lib/underscore", "./lib/signals", "./core", "./item", "./text", "./drag", "./tween", "./grid", "./offset"], function(e, t, n) {
            function v(e) {
                return ["translate(", e.x, ",", e.y, ") rotate(", e.r, ") scale(", e.s, ")"].join("")
            }

            function m(e, t, n, r) {
                return ["translate(", e, ",", t, ") rotate(", n, ") scale(", r, ")"].join("")
            }

            function g(e, t, n) {
                var r = e.getBoundingClientRect();
                return {
                    x: t - r.left,
                    y: n - r.top
                }
            }

            function y(e, t) {
                return e.className.match(new RegExp("(\\s|^)" + t + "(\\s|$)"))
            }

            function b(e, t) {
                y(e, t) || (e.className += " " + t)
            }

            function w(e, t) {
                if (y(e, t)) {
                    var n = new RegExp("(\\s|^)" + t + "(\\s|$)");
                    e.className = e.className.replace(n, " ")
                }
            }

            function E(e, t, n, r, i) {
                var o = s.createSVGElement("line");
                o.setAttribute("x1", t), o.setAttribute("y1", n), o.setAttribute("x2", r), o.setAttribute("y2", i), o.setAttribute("stroke", "rgba(255,255,255,1)"), o.setAttribute("stroke-width", 2), o.setAttribute("stroke-dasharray", 3), o.style.opacity = .7, e.appendChild(o), S(o)
            }

            function S(e) {
                var t = function() {
                    var n = parseFloat(e.style.opacity) - .03;
                    e.style.opacity = n, n > 0 ? setTimeout(t, 10) : e.parentNode.removeChild(e)
                };
                t()
            }

            function T() {
                var e = this.node,
                    t = this.elements.container,
                    n = this.elements.topPanel,
                    r = this.elements.title,
                    i = this.elements.titleTop,
                    o = this.elements.titleShadow,
                    a = this.elements.bottomPanel,
                    f = this.elements.containerBackground,
                    l = this.elements.topBackground,
                    c = this.elements.bottomBackground,
                    h = this.resizer,
                    p = this.settings;
                s.svgSetXYWH(f, 0, 0, p.width, p.height), l.setAttribute("d", s.path.roundedRectangle(0, 0, p.width, p.topPanelHeight, 6, 6, 0, 0)), c.setAttribute("d", s.path.roundedRectangle(0, 0, p.width, p.bottomPanelHeight, 0, 0, 6, 6)), u.addEllipseText(i, p.title, p.width - 2 * p.textMargin), o.textContent = i.textContent, r.setAttribute("transform", "translate(" + p.width / 2 + ", " + p.textOffsetTop + ")"), n.setAttribute("transform", "translate(0, " + -p.topPanelHeight + ")"), a.setAttribute("transform", "translate(0, " + p.height + ")"), h.pos(p.width, p.height)
            }

            function N() {
                var e = this.elements.topBackground;
                this.tweens.hover.stop().to({
                    o: d.mouseOverOpacity
                }, d.mouseOverSpeed).start()
            }

            function C() {
                var e = this.elements.topBackground;
                this.tweens.hover.stop().to({
                    o: d.mouseOutOpacity
                }, d.mouseOutSpeed).start()
            }

            function k(e) {
                var t = this.elements.title,
                    n = this.elements.topPanel,
                    i = this.settings,
                    s = i.title,
                    o = this,
                    u, a, f, l, c;
                if (i.inlineEdit !== !0) return;
                if (this.drag._afterDrag === !0) {
                    this.drag._afterDrag = !1;
                    return
                }
                a = n.getBoundingClientRect(), l = g(this.manager.parent, a.left, a.top), f = t.getBoundingClientRect(), c = g(this.manager.parent, f.left, f.top), u = this._inlineInput = document.createElement("input"), u.type = "text", u.className = "jt-panel-edit-inline", u.maxLength = 50, u.value = i.title, this.on.changed.active = !1, this.title(""), this.settings.title = u.value, this.on.changed.active = !0, u.addEventListener("keydown", function(e) {
                    e.keyCode == 13 ? L.call(o, e) : e.keyCode == 27 && (this.value = s, L.call(o, e))
                }), r.extend(u.style, {
                    display: "block",
                    backgroundColor: "transparent",
                    outline: "none",
                    position: "absolute",
                    left: l.x + i.textMargin + "px",
                    top: c.y + "px",
                    border: "none",
                    width: i.width - 2 * i.textMargin + "px",
                    color: "#FFF",
                    fontFamily: i.fontFamily,
                    fontSize: i.fontSize + "px",
                    textAlign: "center",
                    margin: 0,
                    padding: 0
                }), this.manager.parent.appendChild(u), u.focus(), u.select()
            }

            function L(e) {
                if (this.settings.inlineEdit !== !0) return;
                if (this._inlineInput) {
                    var t = this._inlineInput;
                    this.settings.title !== t.value && t.value !== "" ? this.title(t.value) : (this.on.changed.active = !1, this.title(this.settings.title), this.on.changed.active = !0), this.manager.parent.removeChild(t), this._inlineInput = null
                }
            }
            var r = e("./lib/underscore"),
                i = e("./lib/signals"),
                s = e("./core"),
                o = e("./item"),
                u = e("./text"),
                a = e("./drag"),
                f = e("./tween"),
                l = e("./grid"),
                c = e("./offset"),
                h = "http://www.w3.org/1999/xlink",
                p = "PANEL",
                d = {
                    fontFamily: '"Lucida Grande", "Lucida Sans Unicode", Helvetica, Arial, Verdana',
                    fontSize: 15,
                    mouseOverSpeed: 200,
                    mouseOutSpeed: 200,
                    mouseOverOpacity: .75,
                    mouseOutOpacity: .6,
                    textMargin: 25,
                    alignDistance: 10,
                    alignIndicatorDelay: 70,
                    alignIndicator: !1
                },
                x = o.extend({
                    init: function(e) {
                        this._super();
                        var t = this.settings = r.defaults(e || {}, {
                            radius: 10
                        });
                        r.extend(this.on, {
                            resizeStart: new i,
                            resize: new i,
                            resizeEnd: new i
                        });
                        var n = s.createSVGElement("g");
                        handle = s.createSVGElement("circle"), handle.setAttribute("r", t.radius), handle.setAttribute("fill", "#000"), handle.setAttribute("stroke", "#000"), handle.setAttribute("stroke-width", 1), handle.setAttribute("opacity", 0), handle.setAttribute("transform", "translate(" + -t.radius + "," + 0 + ")"), n.appendChild(handle), n.style.cursor = "nw-resize", this.node = n, a.asDragElement.call(this, {
                            handle: n,
                            checkDragOver: !1,
                            checkDropOver: !1
                        })
                    },
                    dragStart: function(e, t) {
                        this.on.resizeStart.dispatch(e, t, e - this.parent.transform.x, t - this.parent.transform.y), this.dragManager.node.style.cursor = "nw-resize"
                    },
                    dragEnd: function(e, t) {
                        this.on.resizeEnd.dispatch(e, t, e - this.parent.transform.x, t - this.parent.transform.y)
                    },
                    dragMove: function(e, t) {
                        this.on.resize.dispatch(e, t, e - this.parent.transform.x, t - this.parent.transform.y), this.dragManager.node.style.cursor = "nw-resize"
                    }
                }),
                A = o.extend({
                    panels: [],
                    init: function(e) {
                        this._super(e);
                        var t = r.extend(this.settings, {
                            title: "",
                            width: 200,
                            height: 160,
                            minWidh: 100,
                            minHeight: 80,
                            gridW: 100,
                            gridH: 80,
                            fontFamily: d.fontFamily,
                            fontSize: d.fontSize,
                            topPanelHeight: 25,
                            bottomPanelHeight: 6,
                            textOffsetTop: 18,
                            textMargin: d.textMargin,
                            inlineEdit: !0
                        }, e);
                        this.type = p, this.items = {}, this.grid = new l, r.extend(this.on, {
                            changed: new i
                        });
                        var n = s.createSVGElement("g"),
                            o = s.createSVGElement("g"),
                            u = s.createSVGElement("rect"),
                            f = s.createSVGElement("g"),
                            c = s.createSVGElement("path"),
                            h = s.createSVGElement("g"),
                            v = s.createSVGElement("path"),
                            m = s.createSVGElement("g"),
                            g = s.createSVGElement("text"),
                            y = s.createSVGElement("text");
                        s.svgSetXYWH(u, 0, 0, t.width, t.height), u.setAttribute("fill", "#000"), u.setAttribute("opacity", "0.4"), o.appendChild(u), g.setAttribute("font-family", t.fontFamily), g.setAttribute("font-size", t.fontSize), g.setAttribute("fill", "#FFF"), g.setAttribute("text-anchor", "middle"), y.setAttribute("font-family", t.fontFamily), y.setAttribute("font-size", t.fontSize), y.setAttribute("fill", "#000"), y.setAttribute("stroke", "#000"), y.setAttribute("stroke-width", 2.6), y.setAttribute("stroke-opacity", .5), y.setAttribute("text-anchor", "middle"), y.setAttribute("transform", "translate(1, 1)"), m.setAttribute("class", "text"), m.style["-webkit-user-select"] = "none", m.style["-moz-user-select"] = "none", m.appendChild(y), m.appendChild(g), c.setAttribute("d", s.path.roundedRectangle(0, 0, t.width, t.topPanelHeight, 6, 6, 0, 0)), c.setAttribute("fill", "#000"), c.setAttribute("opacity", d.mouseOutOpacity), c.opacity = d.mouseOutOpacity, f.appendChild(c), f.appendChild(m), v.setAttribute("d", s.path.roundedRectangle(0, 0, t.width, t.bottomPanelHeight, 0, 0, 6, 6)), v.setAttribute("fill", "#000"), v.setAttribute("opacity", "0.4"), h.appendChild(v);
                        var b = s.createSVGElement("g"),
                            w = s.createSVGElement("path");
                        w.setAttribute("stroke", "#000"), w.setAttribute("stroke-width", 1), w.setAttribute("stroke-opacity", 0), w.setAttribute("fill", "#000"), w.setAttribute("fill-opacity", .3), w.setAttribute("opacity", "0"), b.setAttribute("transform-origin", "50 50"), b.appendChild(w), n.appendChild(o), n.appendChild(h), n.appendChild(f), n.appendChild(b), n.addEventListener("mouseover", r.bind(N, this)), n.addEventListener("mouseout", r.bind(C, this)), document.addEventListener("mousedown", r.bind(L, this)), f.addEventListener("click", r.bind(k, this)), this.node = n, this.elements = {
                            container: o,
                            containerBackground: u,
                            topPanel: f,
                            topBackground: c,
                            bottomPanel: h,
                            bottomBackground: v,
                            title: m,
                            titleTop: g,
                            titleShadow: y,
                            indicators: b,
                            indicator: w
                        };
                        var E = this.resizer = new x;
                        E.parent = this, n.appendChild(E.node), E.on.resizeStart.add(r.bind(this._resizeStart, this)), E.on.resizeEnd.add(r.bind(this._resizeEnd, this)), E.on.resize.add(r.bind(this._resize, this)), a.asDragElement.call(this, {
                            handle: f,
                            checkDragOver: !1,
                            checkDropOver: !1
                        }), a.asDropElement.call(this, {
                            gridX: -1,
                            gridY: -1
                        }), this.panels.push(this)
                    },
                    title: function(e) {
                        return r.isString(e) && (this.settings.title = e, this.invalidate(), this.on.changed.dispatch({
                            key: "title",
                            value: e
                        })), this
                    },
                    resize: function(e) {
                        if (r.isUndefined(e)) return this.resizer.drag.enabled;
                        e === !0 ? (this.resizer.drag.enabled = !0, this.resizer.node.style.cursor = "nw-resize") : (this.resizer.drag.enabled = !1, this.resizer.node.style.cursor = "default")
                    },
                    getBoundingBox: function() {
                        return {
                            x: this.transform.x,
                            y: this.transform.y - this.settings.topPanelHeight,
                            w: this._bbox.width,
                            h: this._bbox.height
                        }
                    },
                    onAdd: function(e) {
                        e.registerDragItem(this.resizer), this.invalidate();
                        var t = this.elements.topBackground;
                        this.tweens.hover = (new f.Tween({
                            o: t.opacity
                        })).easing(f.Easing.Linear.None).onUpdate(function() {
                            t.opacity = this.o, t.setAttribute("opacity", t.opacity)
                        });
                        var n = this.elements.indicator;
                        n.t = {
                            o: .2,
                            s: 1,
                            r: 0
                        }, this.tweens.indicator = (new f.Tween(n.t)).to({
                            s: 1.5,
                            o: 1,
                            r: 360
                        }, 300).easing(f.Easing.Linear.None).onUpdate(function() {
                            n.setAttribute("opacity", this.o)
                        }), this.tweens.indicatorBack = (new f.Tween(n.t)).to({
                            s: 1,
                            o: .2,
                            r: 0
                        }, 300).easing(f.Easing.Linear.None).onUpdate(function() {
                            n.setAttribute("opacity", this.o)
                        }), this.tweens.indicatorBack.chain(this.tweens.indicator), this.tweens.indicator.chain(this.tweens.indicatorBack)
                    },
                    dragOver: function(e, t, n) {
                        if (e.type === "ICON") {
                            var r = this.settings,
                                i = Math.floor((t - this.transform.x) / r.gridW),
                                s = Math.floor((n - this.transform.y) / r.gridH),
                                o = this.elements.indicator,
                                u = this.elements.indicators;
                            i = i < 0 ? 0 : i * r.gridW >= r.width ? r.width / r.gridW - 1 : i, s = s < 0 ? 0 : s * r.gridH >= r.height ? r.height / r.gridH - 1 : s;
                            if (i !== this.drop.gridX || s !== this.drop.gridY) this.drop.gridX = i, this.drop.gridY = s;
                            var a = this.grid.getValue(i, s);
                            a ? this.manager.node.style.cursor = "not-allowed" : this.manager.node.style.cursor = "move", this.tweens.hover.stop().to({
                                o: d.mouseOverOpacity
                            }, d.mouseOverSpeed).start()
                        }
                    },
                    dragOut: function(e, t, n) {
                        if (e.type === "ICON") {
                            var r = this.elements.indicators;
                            this.drop.gridX = -1, this.drop.gridY = -1, this.manager.node.style.cursor = "move", this.tweens.hover.stop().to({
                                o: d.mouseOutOpacity
                            }, d.mouseOutSpeed).start()
                        }
                    },
                    dropIn: function(e, t, n) {
                        if (e.type === "ICON") {
                            var r = this.settings;
                            indicators = this.elements.indicators, relx = t - this.transform.x, rely = n - this.transform.y, newposx = Math.floor((t - this.transform.x) / r.gridW), newposy = Math.floor((n - this.transform.y) / r.gridH), newposx = newposx < 0 ? 0 : newposx * r.gridW >= r.width ? r.width / r.gridW - 1 : newposx, newposy = newposy < 0 ? 0 : newposy * r.gridH >= r.height ? r.height / r.gridH - 1 : newposy;
                            var i = this.grid.getValue(newposx, newposy);
                            return i ? !1 : (this.drop.gridX = newposx, this.drop.gridY = newposy, e.pos(e.transform.x - this.transform.x, e.transform.y - this.transform.y), e.posAnim(this.drop.gridX * r.gridW, this.drop.gridY * r.gridH, 150, f.Easing.Linear.None), this.addItem(e, this.drop.gridX, this.drop.gridY, !1), this.drop.gridX = -1, this.drop.gridY = -1, indicators.setAttribute("opacity", "0"), this.tweens.indicator.stop(), this.tweens.indicatorBack.stop(), !0)
                        }
                    },
                    dropOut: function(e, t, n) {
                        var r = this.settings;
                        e.type === "ICON" && this.removeItem(e)
                    },
                    dragStart: function(e, t) {
                        this.drag.alignX = !1, this.drag.alignY = !1
                    },
                    dragEnd: function(e, t) {
                        this.pos(this.drag.alignX ? this.drag.alignPosX : this.transform.x, this.drag.alignY ? this.drag.alignPosY : this.transform.y);
                        var n = this;
                        this.drag._afterDrag = !0, r.defer(function() {
                            n.drag._afterDrag = !1
                        })
                    },
                    dragMove: function(e, t) {
                        var n = this,
                            i = r.find(this.panels, function(e) {
                                return e !== n && Math.abs(n.transform.y - e.transform.y) < d.alignDistance
                            });
                        r.isUndefined(i) ? this.drag.alignY = !1 : (this.drag.alignY || (this.drag.alignY = !0, d.alignIndicator && setTimeout(function() {
                            n.drag.alignY && E(n.manager.node, 0, i.transform.y - i.settings.topPanelHeight, n.manager.parent.offsetWidth, i.transform.y - i.settings.topPanelHeight)
                        }, d.alignIndicatorDelay)), this.drag.alignPosY = i.transform.y);
                        var s = r.find(this.panels, function(e) {
                            return e !== n && Math.abs(n.transform.x - e.transform.x) < d.alignDistance
                        });
                        r.isUndefined(s) ? this.drag.alignX = !1 : (this.drag.alignX || (this.drag.alignX = !0, d.alignIndicator && setTimeout(function() {
                            n.drag.alignX && E(n.manager.node, s.transform.x, 0, s.transform.x, n.manager.parent.offsetHeight)
                        }, d.alignIndicatorDelay)), this.drag.alignX = !0, this.drag.alignPosX = s.transform.x);
                        var o = this.drag.alignX ? this.drag.alignPosX : this.transform.x,
                            u = this.drag.alignY ? this.drag.alignPosY : this.transform.y;
                        this.node.setAttribute("transform", v({
                            x: o,
                            y: u,
                            s: n.transform.s,
                            r: n.transform.r
                        }))
                    },
                    addItem: function(e, t, n, i) {
                        if (!r.has(this.items, e.id)) {
                            this.items[e.id] = e, e.on.remove.add(this.removeItem, this), e.parent.grid instanceof l && e.parent.grid.removeValue(e.settings.gridX, e.settings.gridY, e), e.parent.node.removeChild(e.node), e.parent = this, e.parent.node.appendChild(e.node), this.grid.setValue(t, n, e), e.settings.gridX = r.defaults(t, e.settings.gridX), e.settings.gridY = r.defaults(n, e.settings.gridY);
                            var s = this.settings,
                                o = this.grid.getColumnCount(),
                                u = this.grid.getRowCount(),
                                i = r.defaults(i, !0);
                            s.minWidh = s.gridW * o, s.minHeight = s.gridH * u, i && e.pos(e.settings.gridX * s.gridW, e.settings.gridY * s.gridH)
                        }
                    },
                    removeItem: function(e) {
                        if (r.has(this.items, e.id)) {
                            e.on.remove.remove(this.removeItem), this.grid.removeValue(e.settings.gridX, e.settings.gridY, e);
                            var t = this.settings,
                                n = this.grid.getColumnCount(),
                                i = this.grid.getRowCount();
                            t.minWidh = n > 0 ? t.gridW * n : t.gridW, t.minHeight = i > 0 ? t.gridH * i : t.gridH, this.items[e.id] = null, delete this.items[e.id]
                        }
                    },
                    _resizeStart: function(e, t, n, r) {},
                    _resizeEnd: function(e, t, n, i) {
                        var s = this,
                            o = this.settings,
                            u = this.resizer;
                        n = r.max([o.minWidh, n]), i = r.max([o.minHeight, i]), n = Math.floor((n + o.gridW / 2) / o.gridW) * o.gridW, i = Math.floor((i + o.gridH / 2) / o.gridH) * o.gridH, o.width = n, o.height = i, this.invalidate(), this.on.changed.dispatch({
                            key: "size",
                            value: {
                                width: s.settings.width,
                                height: s.settings.height
                            }
                        })
                    },
                    _resize: function(e, t, n, i) {
                        var s = this.settings;
                        n = r.max([s.minWidh, n]), i = r.max([s.minHeight, i]), s.width = n, s.height = i, this.invalidate()
                    },
                    invalidate: function() {
                        T.call(this), this._super()
                    }
                });
            s.Core.inject({
                panel: function(e) {
                    return this.addItem(new A(e))
                }
            }), n.exports = A
        }), n("popupmenu", ["require", "exports", "module", "./lib/underscore", "./class", "./lib/signals", "./core", "./item", "./item.icon", "./tween"], function(e, t, n) {
            function l(e, t) {
                return e.className.match(new RegExp("(\\s|^)" + t + "(\\s|$)"))
            }

            function c(e, t) {
                l(e, t) || (e.className += " " + t)
            }

            function h(e, t) {
                if (l(e, t)) {
                    var n = new RegExp("(\\s|^)" + t + "(\\s|$)");
                    e.className = e.className.replace(n, " ")
                }
            }

            function p(e, t, n) {
                var r = e.getBoundingClientRect();
                return {
                    x: t - r.left,
                    y: n - r.top
                }
            }
            var r = e("./lib/underscore"),
                i = e("./class"),
                s = e("./lib/signals"),
                o = e("./core"),
                u = e("./item"),
                a = e("./item.icon"),
                f = e("./tween"),
                d = i.extend({
                    _sender: null,
                    _menus: [],
                    init: function(e) {
                        var t = this.settings = r.extend({
                                width: 130,
                                defaultSide: "down",
                                showArrow: !0,
                                offsetTop: 70,
                                offsetBottom: 20,
                                iconWidth: 16,
                                iconHeight: 16,
                                elements: {},
                                delay: 0
                            }, e),
                            n = document.getElementsByTagName("body")[0],
                            i = document.createElement("ul"),
                            s = document.createElement("li"),
                            o = document.createElement("div"),
                            u = document.createElement("div"),
                            a = document.createElement("a"),
                            l = document.createElement("div"),
                            h = document.createElement("div");
                        o.appendChild(u), o.appendChild(a), s.appendChild(o), i.appendChild(h), i.appendChild(l), n.appendChild(i), c(i, "jtop-popupmenu"), c(l, "jtop-popupmenu-arrow"), c(h, "jtop-popupmenu-arrow-border"), c(u, "img"), this._style = {
                            opacity: 0
                        }, this._tweenOpacity = (new f.Tween(this._style)).onUpdate(function() {
                            i.style.opacity = this.opacity
                        }).onComplete(function() {
                            this.opacity <= 0 && (i.style.display = "none")
                        }), this._menus.push(this), this._getElementTemplate = function() {
                            return s.cloneNode(!0)
                        }, this._getMenuHtml = function() {
                            return i
                        }, this._getArrow = function() {
                            return l
                        }, this._getArrowBorder = function() {
                            return h
                        }, this._createSeparator = function() {
                            return document.createElement("hr")
                        }, document.addEventListener("mousedown", r.bind(function(e) {
                            this.hide()
                        }, this)), i.addEventListener("mousedown", r.bind(function(e) {
                            e.stopPropagation(), e.preventDefault()
                        }, this)), i.addEventListener("click", r.bind(function(e) {
                            e.stopPropagation(), e.preventDefault(), this.hide()
                        }, this))
                    },
                    addMenuElement: function(e, t, n, i) {
                        var s = this._getMenuHtml(),
                            o = this._getElementTemplate(),
                            u = o.getElementsByTagName("div")[0],
                            a = u.getElementsByTagName("a")[0],
                            f = u.getElementsByClassName("img")[0],
                            l = this;
                        return a.href = "#", a.innerHTML = e, r.isFunction(n) && o.addEventListener("click", function(e) {
                            return e.preventDefault(), n.call(l, l._sender), !1
                        }), r.isString(t) && (f.style.backgroundImage = "url(" + t + ")"), i && i.length > 0 && c(o, i), s.appendChild(o), this
                    },
                    addMenuSeparator: function() {
                        var e = this._getMenuHtml(),
                            t = this._createSeparator();
                        return e.appendChild(t), this
                    },
                    show: function(e, t, n) {
                        var i = this._getMenuHtml(),
                            s = this,
                            o = this._getArrow(),
                            u = this._getArrowBorder(),
                            a = this.settings,
                            f, l, p, d, v;
                        this._sender = e, r.extend(i.style, {
                            display: "block",
                            opacity: "0",
                            top: n + "px",
                            left: t + "px"
                        });
                        var m = i.offsetWidth,
                            g = i.offsetHeight;
                        f = t - m / 2, f - window.pageXOffset < 0 ? f += window.pageXOffset - f + 10 : window.pageXOffset + window.innerWidth - (f + m) < 0 && (f -= f + m - (window.pageXOffset + window.innerWidth) + 25), p = t - f - 7, v = a.defaultSide === "up" && n - g - a.offsetBottom - window.pageYOffset > 0 || a.defaultSide === "down" && window.pageYOffset + window.innerHeight - (n + g + a.offsetTop) < 0, i.style.left = f + "px", i.style.top = v ? n - g - a.offsetBottom + "px" : n + a.offsetTop + "px", v ? (h(o, "jtop-arrowdown"), c(o, "jtop-arrowup"), r.extend(o.style, {
                            left: p + "px"
                        }), h(u, "jtop-arrowdown-border"), c(u, "jtop-arrowup-border"), r.extend(u.style, {
                            left: p + "px"
                        })) : (h(o, "jtop-arrowup"), c(o, "jtop-arrowdown"), r.extend(o.style, {
                            left: p + "px"
                        }), h(u, "jtop-arrowup-border"), c(u, "jtop-arrowdown-border"), r.extend(u.style, {
                            left: p + "px"
                        }));
                        for (var y = 0, b = this._menus.length; y < b; y++) this._menus[y] !== this && this._menus[y].hide();
                        return this._tweenOpacity.stop().to({
                            opacity: "1"
                        }, 100).delay(a.delay).start(), this
                    },
                    hide: function() {
                        var e = this._getMenuHtml(),
                            t = this;
                        return e.style.opacity <= 0 ? this : (this._tweenOpacity.stop().to({
                            opacity: "0"
                        }, 100).start(), this)
                    }
                });
            a.inject({
                menu: function(e) {
                    if (e instanceof d) return this.menu = {
                        menu: e,
                        click: !1
                    }, this.node.addEventListener("mousedown", r.bind(function(e) {
                        this.menu.click = !0
                    }, this)), this.node.addEventListener("mouseup", r.bind(function(t) {
                        t.preventDefault();
                        if (!this.drag.dragging && this.menu.click) {
                            this.menu.click = !1;
                            var n = this.elements.icon.getBoundingClientRect(),
                                r = p(this.manager.parent, n.left, n.bottom);
                            e.show(this, n.left + n.width / 2, n.top)
                        }
                    }, this)), this;
                    return
                }
            }), n.exports = d
        }), n("template", ["require", "exports", "module"], function(e, t, n) {
            var r = {},
                i = function s(e, t) {
                    var n = /\W/.test(e) ? new Function("obj", "var p=[],print=function(){p.push.apply(p,arguments);};with(obj){p.push('" + e.replace(/[\r\t\n]/g, " ").split("<%").join("	").replace(/((^|%>)[^\t]*)'/g, "$1\r").replace(/\t=(.*?)%>/g, "',$1,'").split("	").join("');").split("%>").join("p.push('").split("\r").join("\\'") + "');}return p.join('');") : r[e] = r[e] || s(document.getElementById(e).innerHTML);
                    return t ? n(t) : n
                };
            n.exports = i
        }), n("tooltip", ["require", "exports", "module", "./lib/underscore", "./class", "./lib/signals", "./core", "./item.icon", "./template", "./tween"], function(e, t, n) {
            function l(e, t) {
                return e.className.match(new RegExp("(\\s|^)" + t + "(\\s|$)"))
            }

            function c(e, t) {
                l(e, t) || (e.className += " " + t)
            }

            function h(e, t) {
                if (l(e, t)) {
                    var n = new RegExp("(\\s|^)" + t + "(\\s|$)");
                    e.className = e.className.replace(n, " ")
                }
            }

            function p(e, t, n) {
                var r = e.getBoundingClientRect();
                return {
                    x: t + r.left,
                    y: n + r.top
                }
            }
            var r = e("./lib/underscore"),
                i = e("./class"),
                s = e("./lib/signals"),
                o = e("./core"),
                u = e("./item.icon"),
                a = e("./template"),
                f = e("./tween"),
                d = i.extend({
                    _tooltips: [],
                    init: function(e, t) {
                        if (!(t instanceof o.Core)) return;
                        var n = this.settings = r.extend({
                                marginTop: 20,
                                marginBottom: 20,
                                offsetLeft: 0,
                                offsetTop: 0,
                                showDelay: 0,
                                hideDelay: 0,
                                fadeInSpeed: 200,
                                fadeOutSpeed: 0,
                                toOpacity: 1,
                                className: "jt-tooltip"
                            }, e),
                            i = this,
                            u = document.getElementsByTagName("body")[0],
                            a = document.createElement("div");
                        c(a, n.className), u.appendChild(a), this.active = !1, this._style = {
                            opacity: 0
                        }, this._template = null, this.on = {
                            show: new s
                        }, document.addEventListener("mousemove", r.bind(function(e) {
                            e.preventDefault();
                            if (this.active) {
                                var n = p(t.parent, e.clientX, e.clientY);
                                this.pos(e.clientX, e.clientY)
                            }
                        }, this)), document.addEventListener("mousedown", r.bind(function(e) {
                            this.active && this.hide()
                        }, this)), this._tweenOpacity = (new f.Tween(this._style)).onUpdate(function() {
                            a.style.opacity = this.opacity
                        }).onComplete(function() {
                            i.active || (a.style.display = "none"), i._style.opacity = parseFloat(a.style.opacity)
                        }), this._tooltips.push(this), this._getTooltipHtml = function() {
                            return a
                        }
                    },
                    addTemplate: function(e) {
                        return r.isString(e) && (this._template = a(e)), this
                    },
                    show: function(e, t, n) {
                        var r = this._getTooltipHtml(),
                            i = this,
                            s = this.settings,
                            o = {};
                        return this.active = !0, this.on.show.dispatch(e, o), r.innerHTML = this._template(o), r.style.display == "none" && (r.style.display = "block"), this.pos(t, n), this._tweenOpacity.stop().to({
                            opacity: s.toOpacity
                        }, s.fadeInSpeed).delay(s.showDelay).start(), this
                    },
                    pos: function(e, t) {
                        var n = this._getTooltipHtml(),
                            i = this.settings,
                            s = this,
                            o = e + i.offsetLeft,
                            u = t + i.offsetTop;
                        r.extend(n.style, {
                            top: u + "px",
                            left: o + "px"
                        });
                        var a = n.getBoundingClientRect(),
                            f = 0,
                            l = 0;
                        a.top - i.marginTop < 0 ? f = -(a.top - i.marginTop) : a.bottom + i.marginBottom > window.innerHeight && (f = -Math.abs(a.bottom + i.marginBottom - window.innerHeight)), a.left < 0 ? l = -a.left : a.right > window.innerWidth && (l = -a.width - 2 * i.offsetLeft), r.extend(n.style, {
                            top: u + f + "px",
                            left: o + l + "px"
                        })
                    },
                    hide: function() {
                        var e = this._getTooltipHtml(),
                            t = this.settings,
                            n = this;
                        return this.active = !1, this._tweenOpacity.stop().to({
                            opacity: 0
                        }, t.fadeOutSpeed).delay(t.hideDelay).start(), this
                    }
                });
            u.inject({
                tooltip: function(e) {
                    if (e instanceof d) return this._tooltip = e, this.node.addEventListener("mouseover", r.bind(function(e) {
                        e.preventDefault();
                        if (!this.manager._drag.dragging) {
                            var t = p(this.manager.parent, e.clientX, e.clientY);
                            this._tooltip.show(this, e.clientX, e.clientY)
                        }
                    }, this)), this.node.addEventListener("mouseout", r.bind(function(e) {
                        e.preventDefault(), this._tooltip.hide()
                    }, this)), this;
                    return
                }
            }), o.Core.inject({
                tooltip: function(e) {
                    return new d(e, this)
                }
            }), n.exports = d
        }), n("scrollview", ["require", "exports", "module", "./lib/underscore", "./lib/signals", "./class", "./core", "./tween"], function(e, t, n) {
            function f(e, t) {
                return e.className.match(new RegExp("(\\s|^)" + t + "(\\s|$)"))
            }

            function l(e, t) {
                f(e, t) || (e.className += " " + t)
            }

            function c(e, t) {
                if (f(e, t)) {
                    var n = new RegExp("(\\s|^)" + t + "(\\s|$)");
                    e.className = e.className.replace(n, " ")
                }
            }

            function h(e, t, n) {
                var r = e.getBoundingClientRect();
                return {
                    x: t - r.left,
                    y: n - r.top
                }
            }

            function p(e) {
                var t = this,
                    n = this.layer.getBoundingClientRect();
                this.viewportWidth = window.innerWidth, this.viewportHeight = window.innerHeight, this.maxOffsetX = r.max([n.right - this.viewportWidth, 0]), this.maxOffsetY = r.max([n.bottom - this.viewportHeight, 0]), this.maxOffsetX > 0 ? (this.elements.htmlArrowLeft.style.display = "none", this.elements.htmlArrowRight.style.display = "block") : (this.elements.htmlArrowLeft.style.display = "none", this.elements.htmlArrowRight.style.display = "none"), this.maxOffsetY > 0 ? (this.elements.htmlArrowUp.style.display = "none", this.elements.htmlArrowDown.style.display = "block") : (this.elements.htmlArrowUp.style.display = "none", this.elements.htmlArrowDown.style.display = "none"), r.extend(this.elements.htmlArrowUp.style, {
                    top: a.activationArea / 2 + this.initY + "px",
                    left: t.viewportWidth / 2 - 15 + "px"
                }), r.extend(this.elements.htmlArrowDown.style, {
                    bottom: a.activationArea / 2 + "px",
                    left: t.viewportWidth / 2 - 15 + "px"
                }), r.extend(this.elements.htmlArrowLeft.style, {
                    left: a.activationArea + "px",
                    top: this.viewportHeight / 2 - 15 + "px"
                }), r.extend(this.elements.htmlArrowRight.style, {
                    left: this.viewportWidth - a.activationArea + "px",
                    top: this.viewportHeight / 2 - 15 + "px"
                }), this.on.resize.dispatch(this)
            }

            function d(e) {
                if (!this.enabled) return;
                var t = this;
                this.arrowsOpacityAnim(.5), clearTimeout(this.hideTimeout), this.hideTimeout = setTimeout(function() {
                    t.arrowsOpacityAnim(0)
                }, 1e3), this.maxOffsetX > 0 && (e.clientX >= 0 && e.clientX <= a.activationArea + this.initY ? (this.on.scroll.dispatch(this, this.SCROLL_DIRECTION.LEFT), this.posAnim(this.initX, this.transform.y, this.SCROLL_DIRECTION.LEFT), this.elements.htmlArrowLeft.style.display = "none", this.elements.htmlArrowRight.style.display = "block") : e.clientX > this.viewportWidth - a.activationArea && e.clientX <= this.viewportWidth && (this.on.scroll.dispatch(this, this.SCROLL_DIRECTION.RIGHT), this.posAnim(this.initX - this.maxOffsetX, this.transform.y, this.SCROLL_DIRECTION.RIGHT), this.elements.htmlArrowLeft.style.display = "block", this.elements.htmlArrowRight.style.display = "none")), this.maxOffsetY > 0 && (e.clientY >= 0 && e.clientY <= a.activationArea + this.initY ? (this.on.scroll.dispatch(this, this.SCROLL_DIRECTION.TOP), this.posAnim(this.transform.x, this.initY, this.SCROLL_DIRECTION.TOP), this.elements.htmlArrowUp.style.display = "none", this.elements.htmlArrowDown.style.display = "block") : e.clientY > this.viewportHeight - a.activationArea && e.clientY <= this.viewportHeight && (this.on.scroll.dispatch(this, this.SCROLL_DIRECTION.BOTTOM), this.posAnim(this.transform.x, this.initY - this.maxOffsetY, this.SCROLL_DIRECTION.BOTTOM), this.elements.htmlArrowUp.style.display = "block", this.elements.htmlArrowDown.style.display = "none"))
            }
            var r = e("./lib/underscore"),
                i = e("./lib/signals"),
                s = e("./class"),
                o = e("./core"),
                u = e("./tween"),
                a = {
                    activationArea: 40,
                    transformAnimDuration: 500,
                    transformAnimTween: u.Easing.Back.Out
                },
                v = s.extend({
                    SCROLL_DIRECTION: {
                        TOP: 1,
                        LEFT: 2,
                        BOTTOM: 3,
                        RIGHT: 4
                    },
                    init: function(e) {
                        var t = this;
                        this.settings = r.defaults(e._settings.scrollView || {}, {
                            initX: 0,
                            initY: 0
                        }), this.desktop = e, this.layer = e.parent, this.layers = [], this.enabled = !0, window.addEventListener("resize", r.bind(p, this)), window.addEventListener("mousemove", r.bind(d, this));
                        var n = this.layer.getBoundingClientRect();
                        this.viewportWidth = window.innerWidth, this.viewportHeight = window.innerHeight, this.maxOffsetX = n.right - this.viewportWidth, this.maxOffsetY = n.bottom - this.viewportHeight, this.initX = this.settings.initX, this.initY = this.settings.initY, this.transform = {
                            x: this.maxOffsetX > 0 ? n.left : t.initX,
                            y: this.maxOffsetY > 0 ? n.top : t.initY
                        }, this.on = {
                            scroll: new i,
                            resize: new i
                        }, this.tweens = {}, this.posAnimState = !1, this.tweens.pos = (new u.Tween(this.transform)).easing(u.Easing.Elastic.Out).onComplete(function() {
                            t.posAnimState = !1
                        }).onUpdate(function() {
                            t.maxOffsetX > 0 && (t.layer.style.left = this.x + "px"), t.maxOffsetY > 0 && (t.layer.style.top = this.y + "px");
                            for (var e = t.layers.length - 1; e >= 0; e--) t.maxOffsetX > 0 && (t.layers[e].style.left = this.x + "px"), t.maxOffsetY > 0 && (t.layers[e].style.top = this.y + "px")
                        }), this.elements = {
                            htmlArrowUp: document.createElement("div"),
                            htmlArrowDown: document.createElement("div"),
                            htmlArrowLeft: document.createElement("div"),
                            htmlArrowRight: document.createElement("div")
                        }, r.extend(this.elements.htmlArrowUp.style, {
                            position: "fixed",
                            top: a.activationArea / 2 + this.initY + "px",
                            left: this.viewportWidth / 2 - 15 + "px",
                            "border-color": "transparent transparent #FFF transparent",
                            opacity: 0
                        }), r.extend(this.elements.htmlArrowDown.style, {
                            position: "fixed",
                            bottom: a.activationArea / 2 + "px",
                            left: this.viewportWidth / 2 - 15 + "px",
                            "border-color": "#FFF transparent transparent transparent",
                            opacity: 0
                        }), r.extend(this.elements.htmlArrowLeft.style, {
                            position: "fixed",
                            left: a.activationArea + "px",
                            top: this.viewportHeight / 2 - 15 + "px",
                            "border-color": "transparent #FFF transparent transparent",
                            opacity: 0
                        }), r.extend(this.elements.htmlArrowRight.style, {
                            position: "fixed",
                            left: this.viewportWidth - a.activationArea + "px",
                            top: this.viewportHeight / 2 - 15 + "px",
                            "border-color": "transparent transparent transparent #FFF",
                            opacity: 0
                        }), l(this.elements.htmlArrowUp, "jtop-popupmenu-arrow"), l(this.elements.htmlArrowDown, "jtop-popupmenu-arrow"), l(this.elements.htmlArrowLeft, "jtop-popupmenu-arrow"), l(this.elements.htmlArrowRight, "jtop-popupmenu-arrow"), document.body.appendChild(this.elements.htmlArrowUp), document.body.appendChild(this.elements.htmlArrowDown), document.body.appendChild(this.elements.htmlArrowLeft), document.body.appendChild(this.elements.htmlArrowRight), this.arrows = {
                            opacity: 0
                        }, this.arrowsShowing = !1, this.arrowsHiding = !1, this.hideTimeout = null, this.tweens.arrowOpacity = (new u.Tween(this.arrows)).easing(u.Easing.Elastic.Out).onComplete(function() {
                            t.arrowsShowing = !1, t.arrowsHiding = !1
                        }).onUpdate(function() {
                            t.elements.htmlArrowUp.style.opacity = this.opacity, t.elements.htmlArrowDown.style.opacity = this.opacity, t.elements.htmlArrowLeft.style.opacity = this.opacity, t.elements.htmlArrowRight.style.opacity = this.opacity
                        }), p.call(this)
                    },
                    arrowsOpacityAnim: function(e, t, n) {
                        if (this.arrowsHiding && e === 0) return;
                        if (this.arrowsShowing && e > 0) return;
                        return e > 0 ? (this.arrowsHiding = !1, this.arrowsShowing = !0) : (this.arrowsHiding = !0, this.arrowsShowing = !1), this.tweens.arrowOpacity.stop().to({
                            opacity: e
                        }, t || a.transformAnimDuration).easing(n || a.transformAnimTween).start(), this
                    },
                    posAnim: function(e, t, n, r, i) {
                        if (this.posAnimState === n) return;
                        return this.posAnimState = n, this.tweens.pos.stop().to({
                            x: e,
                            y: t
                        }, r || a.transformAnimDuration).easing(i || a.transformAnimTween).start(), this
                    },
                    addLayer: function(e, t, n) {
                        var r = document.getElementById(e);
                        if (!r) return;
                        var i = r.getBoundingClientRect();
                        return r.initX = t || 0, r.initY = n || 0, this.layers.push(r), p.call(this), r
                    }
                });
            o.Core.inject({
                init: function(e, t) {
                    this._super(e, t), this.scrollView = new v(this)
                }
            })
        }), n("jtop", ["require", "exports", "module", "./item.icon", "./item.panel", "./popupmenu", "./tooltip", "./scrollview"], function(e, t, n) {
            var r = e("./core"),
                i = e("./popupmenu");
            n.exports = {
                init: function(e, t) {
                    return new r.Core(e, t)
                },
                popupmenu: function(e) {
                    return new i(e)
                }
            }
        }), t(["jtop"]), window.jtop = t("jtop")
})()