(function(){
	
	registerDrag($('#container'));


	//保存原来文本，输入为空时还显示这个文本
	var p_text = "";
	$.each($(".dragger input"), function(index, value){
		//编辑文本框获取焦点
		$(this).on("focus",function(){
			$(this).css("border-color","#000");
			p_text = $(this).val();
		})
		//实时更改文本值
		$(this).on("input",function(){
			$(this).parent().find("p").text($(this).val());
		})
		//编辑文本框失去焦点
		$(this).on("blur",function(){
			$(this).css("border-color","transparent");
			if($(this).val() == ""){
				$(this).val(p_text);
				$(this).parent().find("p").text(p_text);
			}
			$(this).hide();
		})
	});
	//双击p标签编辑文本
	$.each($(".dragger p"), function(index, value){
		//编辑文本框获取焦点
		$(this).on("dblclick",function(){
			if($('#container').attr("data-onOff") == "on"){
				$(this).parent().find("input").show().focus();
			}
		})
		
	});
})();