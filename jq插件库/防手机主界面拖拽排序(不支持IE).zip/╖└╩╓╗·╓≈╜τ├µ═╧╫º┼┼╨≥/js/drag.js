// ¶ÓÁÐÊý×é
var queueArr = [];
// ¿ÉÍÏ¶¯¶ÔÏóÊý×é
var draggers = [];
// ÊÇ·ñÔÚ±»ÍÏ¶¯
var isDragging = false;
// Êó±êÊÇ·ñÔÚÄ³¸öÍÏ¶¯ÉÏ°´ÏÂ
var isMouseDown = false;
// ±»ÍÏ¶¯µÄ¶ÔÏó
var dragger = null;
// ¸Õ¿ªÊ¼ÍÏ¶¯Ê±µÄÊó±êºá×ø±ê
var mouseX;
// ¸Õ¿ªÊ¼ÍÏ¶¯Ê±µÄÊó±ê×Ý×ø±ê
var mouseY;
// ¸Õ¿ªÊ¼ÍÏ¶¯Ê±µÄÍÏ¶¯¶ÔÏóºá×ø±ê
var draggerLeft;
// ¸Õ¿ªÊ¼ÍÏ¶¯Ê±µÄÍÏ¶¯¶ÔÏó×Ý×ø±ê
var draggerTop;
// µ±Ç°ÍÏ¶¯¶ÔÏóµÄÒ»¸ö¿ËÂ¡£¬¸ú×ÅÊó±êÒÆµ½
var clone = null;
// ÍÏ¶¯µ½ÁéÃô¶È
var DRAG_THRESHOLD = 5;
// °üº¬ËùÓÐ¶ÓÁÐµÄÈÝÆ÷
var queueContainer;
// ¶ÓÁÐÑ¡ÖÐÊ±µÄborder
var queueActive = {'border': '1px solid #e85032'};
// ¶ÓÁÐÎ´Ñ¡ÖÐÊ±µÄborder
var queueUnActive = {'border': '1px solid #2db9c7'};
//最外层边框
var wrap_box = document.getElementsByClassName("device")[0];
var box_l;
var box_r;

var registerDrag = function(container){	
	queueContainer = container;
	$.each(container.find('.queue'), function(index, value){
		queueArr[index] = $(value);
		draggers[index] = [];
		elements = $(value).find('.dragger');
		$.each(elements, function(_index, _value){
			draggers[index][_index] = $(_value); 
		});
	});
	if($('#container').attr("data-onOff") == "on"){
		for(var i=0;i<draggers.length;i++)
		for(var j=0;j<draggers[i].length;j++){
			draggers[i][j].on('mousedown', dragStart);
		}
		$(document).on('mousemove', dragMove);
		$(document).on('mouseup', dragEnd);
	}
	
	
}

var dragStart = function(e){
	e.stopPropagation();
	
	isMouseDown = true;
	mouseX = e.clientX;
	mouseY = e.clientY;
	dragger = $(this);
	//获取最外层左边框和右边框坐标
	box_l = getOffsetLeft(wrap_box);
	box_r = getOffsetRight(wrap_box,wrap_box.offsetWidth);
}

var dragMove = function(e){
	e.stopPropagation();

	if(!isMouseDown) return;
	//判断是否超出左右边框
	if(e.clientX <= box_l){
		e.preventDefault();
		mySwiper.swipePrev();
	}
	if(e.clientX > box_r){
		e.preventDefault();
    	mySwiper.swipeNext();
	}
	var dx = e.clientX - mouseX;
	var dy = e.clientY - mouseY;
	if(isDragging){
		console.log(1111111111)
		clone.css({left: draggerLeft + dx, top: draggerTop + dy});
		arrangeDragger();
	}else if(Math.abs(dx)>DRAG_THRESHOLD || Math.abs(dy)>DRAG_THRESHOLD){
		console.log(2222222222222)
		clone = makeClone(dragger);
		draggerLeft = dragger.offset().left - parseInt(dragger.css('margin-left')) - parseInt(dragger.css('padding-left'));
		draggerTop = dragger.offset().top - parseInt(dragger.css('margin-top')) - parseInt(dragger.css('padding-top'));
		clone.css({left: draggerLeft, top: draggerTop});
		queueContainer.append(clone);
		dragger.css('visibility', 'hidden');
		isDragging = true;
	}
}

var dragEnd = function(e){
	e.stopPropagation();
	if(isDragging){
		isDragging = false;
		clone.remove();
		dragger.css('visibility', 'visible');
	}
	for(var i=0;i<queueArr.length;i++)
		queueArr[i].css(queueUnActive);
	isMouseDown = false;
}

var makeClone = function(source){
	var res = source.clone();
	res.css({position: 'absolute', 'z-index': 100000});
	return res;
}

var arrangeDragger = function(){
	for(var i=0;i<queueArr.length;i++)
		queueArr[i].css(queueUnActive);
	var queueIn = findQueue();
	if(queueIn != -1)
		queueArr[queueIn].css(queueActive);
	var hover = findHover(queueIn);
	if(hover == null)
		return;
	var _hover = hover.hover;
	var _insert = hover.insert;
	var queueIdOriginal, drggerIdOriginal;
	var queueIdHover, drggerIdHover;
	for(var i=0;i<draggers.length;i++)
		for(var j=0;j<draggers[i].length;j++){
			if(draggers[i][j][0] == dragger[0]){
				queueIdOriginal = i;
				drggerIdOriginal = j;
			}
		}
	draggers[queueIdOriginal].splice(drggerIdOriginal, 1);
	if(_hover){	
		for(var i=0;i<draggers.length;i++)
			for(var j=0;j<draggers[i].length;j++){
				if(_hover && draggers[i][j][0] == _hover[0]){
					queueIdHover = i;
					drggerIdHover = j;
				}
			}
		if(_insert == 'left'){
			_hover.before(dragger);
			draggers[queueIdHover].splice(drggerIdHover, 0, dragger);
		}
		else{
			_hover.after(dragger);
			draggers[queueIdHover].splice(drggerIdHover + 1, 0, dragger);
		}
	}else{
		draggers[queueIn].push(dragger);
		queueArr[queueIn].append(dragger);
	}
	// console.log('1111111111111');
	for(var i=0;i<draggers.length;i++){
		for(var j=0;j<draggers[i].length;j++){
			// console.log(draggers[i][j][0]);
		}
	}
	// console.log('22222222222222');
}

var findQueue = function(){
	var mx=-1,pos=-1;
	var cloneTop = clone.offset().left;
	var cloneHeight = clone.width();
	for(var i=0;i<queueArr.length;i++){
		var queueTop = queueArr[i].offset().left;
		var queueHeight = queueArr[i].width();
		var val = Math.min(queueTop + queueHeight, cloneTop + cloneHeight) - Math.max(queueTop, cloneTop);
		if(val > mx){
			mx = val;
			pos = i;
		}
	}
	return pos;
}

 var findHover = function(queueIn){
	if(queueIn == -1)
		return null;
	var mx=-1,pos=null;
	var cloneTop = clone.offset().top;
	var cloneHeight = clone.height();
	var cloneLeft = clone.offset().left;
	var cloneWidth = clone.width();
	var isOwn = false;
	for(var i=0;i<draggers[queueIn].length;i++){
		
		var _draggerTop = draggers[queueIn][i].offset().top;
		var _draggerHeight = draggers[queueIn][i].height();
		var vertical = Math.min(_draggerTop + _draggerHeight, cloneTop + cloneHeight) - Math.max(_draggerTop, cloneTop);
		
		var _draggerLeft = draggers[queueIn][i].offset().left;
		var _draggerWidth = draggers[queueIn][i].width();
		var horizontal = Math.min(_draggerLeft + _draggerWidth, cloneLeft + cloneWidth) - Math.max(_draggerLeft, cloneLeft);
		
		if(vertical <= 0 || horizontal <=0) continue;
		var s = vertical * horizontal;
		if(s <= cloneHeight * cloneWidth /3)
			continue;
		if(draggers[queueIn][i][0] == dragger[0]){
			isOwn = true;
			continue;
		}
		if(s > mx){
			mx = s;
			pos = draggers[queueIn][i];
		}
	}
	if(mx < 0){
		if(isOwn) return null;
		if(draggers[queueIn].length == 0){
			return {'hover': null};
		}else{
			var last,index=draggers[queueIn].length - 1;
			while(index>=0 && draggers[queueIn][index][0] == dragger[0])
				index--;
			if(index >= 0)
				last = draggers[queueIn][index];
			else
				return {'hover': null};
			if(cloneLeft)
				return {'hover': last, 'insert': 'right'};
			else
				return null;
		}
	}
	else{
		var posMid = (2* pos.offset().left + pos.width());
		var cloneMid = (2* clone.offset().left + clone.width());
		if(posMid > cloneMid)
			return {'hover': pos, 'insert': 'left'};
		else
			return {'hover': pos, 'insert': 'right'};
	}
 }

var getOffsetLeft = function(obj){
      	var tmp = obj.offsetLeft;
      	var val = obj.offsetParent;
      	while(val != null){
      	tmp += val.offsetLeft;
        	val = val.offsetParent;
       	}
    	return tmp;
}
   
      
var getOffsetRight =  function(obj,w){
       	var tmp = obj.offsetLeft;
       	var val = obj.offsetParent;
        while(val != null){
        tmp += val.offsetLeft;
        	val = val.offsetParent;
        }
        return tmp+w;
}